#include <stdio.h>
#include "header.h"

void stampa_var_extern(void) {
    printf("file2: var_extern=%d\n", var_extern);
}
