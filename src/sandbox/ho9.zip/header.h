#ifndef HEADER_H
#define HEADER_H

// Dichiarazione extern (definita in file1.c)
extern int var_extern;

// Prototipi funzioni
void modifica_var_extern(void);
void stampa_var_extern(void);

#endif
