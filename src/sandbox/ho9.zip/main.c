#include "header.h"

int main() {
    modifica_var_extern(); 
    stampa_var_extern();   
    
    modifica_var_extern(); 
    stampa_var_extern();   
    
    return 0;
}
