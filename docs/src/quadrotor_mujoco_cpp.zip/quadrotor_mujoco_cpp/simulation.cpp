#include "simulation.hpp"
#include "math_utils.hpp"   /* per M_PI */
#include <cstdio>
#include <cmath>

Simulation::Simulation(const std::string& xml_path)
{
    char error[1024] = "";
    m_ = mj_loadXML(xml_path.c_str(), nullptr, error, sizeof(error));
    if (!m_)
        throw std::runtime_error(std::string("mj_loadXML: ") + error);

    d_ = mj_makeData(m_);
    if (!d_) {
        mj_deleteModel(m_);
        throw std::runtime_error("mj_makeData failed");
    }

    std::printf("Modello caricato: %d DOF, %d attuatori, dt=%.4f s\n",
                m_->nv, m_->nu, m_->opt.timestep);
}

Simulation::~Simulation()
{
    mj_deleteData(d_);
    mj_deleteModel(m_);
}

void Simulation::step()
{
    mj_step(m_, d_);
}

void Simulation::reset()
{
    mj_resetData(m_, d_);
    apply_perturbation_internal();
}

void Simulation::set_perturbation(double roll_deg, double pitch_deg)
{
    perturb_roll_  = roll_deg;
    perturb_pitch_ = pitch_deg;
    apply_perturbation_internal();
}

void Simulation::apply_perturbation_internal()
{
    /* Quaternione ZYX da roll e pitch (yaw=0):
     *   q = Ry(pitch) * Rx(roll)
     *   w = cr*cp,  x = sr*cp,  y = cr*sp,  z = -sr*sp */
    const double r0 = perturb_roll_  * M_PI/180.0;
    const double p0 = perturb_pitch_ * M_PI/180.0;
    const double cr = std::cos(r0/2), sr = std::sin(r0/2);
    const double cp = std::cos(p0/2), sp = std::sin(p0/2);
    d_->qpos[3] =  cr*cp;   /* w */
    d_->qpos[4] =  sr*cp;   /* x */
    d_->qpos[5] =  cr*sp;   /* y */
    d_->qpos[6] = -sr*sp;   /* z */
}
