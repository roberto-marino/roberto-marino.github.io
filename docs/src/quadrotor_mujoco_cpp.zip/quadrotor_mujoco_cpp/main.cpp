/*
 * main.cpp  —  Quadrotor Hover (C++17, MuJoCo 3.x)
 * ===================================================
 * Crea le tre classi, le connette, avvia il loop.
 *
 * Il main non contiene fisica, matematica o rendering
 */

#include "simulation.hpp"
#include "controller.hpp"
#include "renderer.hpp"
#include <cstdio>

int main(int argc, char** argv)
{
    const std::string xml = (argc > 1) ? argv[1] : "drone.xml";

    /* ── Simulazione ──────────────────────────────────────────── */
    Simulation sim(xml);
    sim.set_perturbation(5.0, 10.0);   /* roll=5°, pitch=10° */

    /* ── Controllore ──────────────────────────────────────────── */
    Controller ctrl;   /* usa i default di CtrlParams */

    /* ── Renderer ─────────────────────────────────────────────── */
    Renderer renderer;
    if (!renderer.init()) return 1;
    renderer.make_context(sim.model());

    /* Quando l'utente preme R: resetta sim e riapplica perturbazione */
    renderer.on_reset = [&]() { sim.reset(); };

    /* ── Loop principale ──────────────────────────────────────── */
    constexpr double RENDER_PERIOD = 1.0 / Renderer::RENDER_HZ;
    constexpr double SIM_DURATION  = 30.0;
    constexpr int    LOG_EVERY     = 500;   /* passi tra una stampa e l'altra */
    int step_cnt = 0;

    std::printf("\nHover target: x=%.1f y=%.1f z=%.1f m\n"
                "Perturbazione iniziale: roll=5 pitch=10 deg\n\n",
                ctrl.params().x_des,
                ctrl.params().y_des,
                ctrl.params().z_des);

    while (!renderer.should_close() && sim.time() < SIM_DURATION)
    {
        const double t0 = sim.time();

        /* ── Avanza la simulazione di un frame di rendering ───── */
        if (!renderer.is_paused()) {
            while (sim.time() - t0 < RENDER_PERIOD) {
                ctrl.compute(sim.model(), sim.data());
                sim.step();

                if (++step_cnt % LOG_EVERY == 0)
                    std::printf("t=%6.2f  x=%+6.3f  y=%+6.3f  z=%6.3f\n",
                                sim.time(),
                                sim.data()->qpos[0],
                                sim.data()->qpos[1],
                                sim.data()->qpos[2]);
            }
        }

        /* ── Aggiorna grafici scrolling ───────────────────────── */
        const float dt_plot = (float)(sim.time() - t0);
        if (!renderer.is_paused() && dt_plot > 0.0f)
            renderer.update_plots(sim.data(), dt_plot, ctrl.params().z_des);

        /* ── Disegna il frame ─────────────────────────────────── */
        renderer.render_frame(sim.model(), sim.data(),
                              ctrl.params().x_des,
                              ctrl.params().y_des,
                              ctrl.params().z_des);
    }

    std::printf("\nSimulazione terminata a t=%.2f s\n", sim.time());
    return 0;
}
