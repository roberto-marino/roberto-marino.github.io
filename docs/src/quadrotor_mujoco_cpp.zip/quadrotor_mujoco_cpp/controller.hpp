#pragma once
#include <mujoco/mujoco.h>
#include <utility>

/*
 * CtrlParams
 * ----------
 * Tutti i guadagni e i setpoint con valori di default.
 * Modificabili a runtime tramite Controller::params().
 */
struct CtrlParams {
    /* Loop altitudine */
    double Kp_z     = 12.0,  Kd_z     =  5.0;
    /* Loop assetto (inner) */
    double Kp_roll  =  8e-4, Kd_roll  =  2e-4;
    double Kp_pitch =  8e-4, Kd_pitch =  2e-4;
    double Kp_yaw   =  2e-4, Kd_yaw   =  5e-5;
    /* Loop posizione x/y (outer-outer) */
    double Kp_xy    =  2.5,  Kd_xy    =  2.0;
    double max_tilt =  0.3;                     /* [rad]  ~17 deg */
    /* Setpoint */
    double x_des    =  0.0,  y_des    =  0.0;
    double z_des    =  0.5,  yaw_des  =  0.0;
};

/*
 * Controller
 * ----------
 * Implementa la cascata a tre livelli:
 *   posizione x/y  →  phi_des, theta_des
 *   altitudine     →  f_total
 *   assetto        →  tau_x, tau_y, tau_z
 *   mixing         →  ctrl[0..3]
 *
 * L'unica interfaccia pubblica è compute(m, d):
 * legge qpos/qvel e scrive ctrl[].
 */
class Controller {
public:
    explicit Controller(CtrlParams params = {})
        : p_(std::move(params)) {}

    void compute(const mjModel* m, mjData* d);

    const CtrlParams& params() const { return p_; }
    CtrlParams&       params()       { return p_; }

private:
    CtrlParams p_;

    static constexpr double GRAVITY    = 9.81;
    static constexpr double DRONE_MASS = 0.027;
    static constexpr double ARM_LENGTH = 0.046;
    static constexpr double KM_KF      = 0.016;
    static constexpr double MAX_THRUST = 0.15;
};
