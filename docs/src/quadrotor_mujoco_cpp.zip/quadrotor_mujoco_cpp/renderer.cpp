#include "renderer.hpp"
#include "math_utils.hpp"
#include <cstdio>
#include <cstring>
#include <algorithm>

/* ═══════════════════════════════════════════════════════════════
 *  Costruttore / Distruttore
 * ═══════════════════════════════════════════════════════════════ */

Renderer::Renderer()
{
    mjv_defaultCamera(&cam_);
    mjv_defaultOption(&opt_);
    mjv_defaultScene(&scn_);
    mjr_defaultContext(&ctx_);
}

Renderer::~Renderer()
{
    if (ctx_ok_)   mjr_freeContext(&ctx_);
    if (scene_ok_) mjv_freeScene(&scn_);
    if (win_)      glfwDestroyWindow(win_);
    if (glfw_ok_)  glfwTerminate();
}

/* ═══════════════════════════════════════════════════════════════
 *  Inizializzazione
 * ═══════════════════════════════════════════════════════════════ */

bool Renderer::init(int w, int h, const std::string& title)
{
    if (!glfwInit()) {
        std::fprintf(stderr, "GLFW init fallita\n");
        return false;
    }
    glfw_ok_ = true;

    win_ = glfwCreateWindow(w, h, title.c_str(), nullptr, nullptr);
    if (!win_) {
        std::fprintf(stderr, "Creazione finestra GLFW fallita\n");
        return false;
    }
    glfwMakeContextCurrent(win_);
    glfwSwapInterval(1);

    /* Salva this nel puntatore utente della finestra:
     * le callback statiche lo usano per risalire all'istanza. */
    glfwSetWindowUserPointer   (win_, this);
    glfwSetKeyCallback         (win_, cb_keyboard);
    glfwSetMouseButtonCallback (win_, cb_mousebutton);
    glfwSetCursorPosCallback   (win_, cb_mousemove);
    glfwSetScrollCallback      (win_, cb_scroll);

    /* Camera di default */
    cam_.distance  = 1.6;
    cam_.elevation = -20.0;
    cam_.azimuth   = 135.0;
    opt_.flags[mjVIS_CONTACTPOINT] = 1;

    init_fig_thrust();
    init_fig_state();
    return true;
}

void Renderer::make_context(const mjModel* m)
{
    model_ = m;
    mjv_makeScene(m, &scn_, 2000);
    scene_ok_ = true;
    mjr_makeContext(m, &ctx_, mjFONTSCALE_150);
    ctx_ok_ = true;
}

/* ═══════════════════════════════════════════════════════════════
 *  GLFW — Callback statiche
 *  Ogni callback recupera l'istanza da glfwGetWindowUserPointer
 *  e delega al metodo di istanza corrispondente.
 * ═══════════════════════════════════════════════════════════════ */

void Renderer::cb_keyboard(GLFWwindow* win, int key, int sc, int act, int mod)
{
    (void)sc; (void)mod;
    static_cast<Renderer*>(glfwGetWindowUserPointer(win))->on_keyboard(key, act);
}

void Renderer::cb_mousebutton(GLFWwindow* win, int btn, int act, int mod)
{
    (void)mod;
    static_cast<Renderer*>(glfwGetWindowUserPointer(win))->on_mousebutton(win, btn, act);
}

void Renderer::cb_mousemove(GLFWwindow* win, double x, double y)
{
    static_cast<Renderer*>(glfwGetWindowUserPointer(win))->on_mousemove(win, x, y);
}

void Renderer::cb_scroll(GLFWwindow* win, double xoff, double yoff)
{
    (void)xoff;
    static_cast<Renderer*>(glfwGetWindowUserPointer(win))->on_scroll(yoff);
}

/* ═══════════════════════════════════════════════════════════════
 *  GLFW — Handler di istanza
 * ═══════════════════════════════════════════════════════════════ */

void Renderer::on_keyboard(int key, int act)
{
    if (act != GLFW_PRESS) return;
    switch (key) {
        case GLFW_KEY_ESCAPE:
            glfwSetWindowShouldClose(win_, GLFW_TRUE);
            break;
        case GLFW_KEY_P:
            paused_ = !paused_;
            break;
        case GLFW_KEY_R:
            reset_plots();
            if (on_reset) on_reset();   /* delega al main la logica di sim reset */
            break;
    }
}

void Renderer::on_mousebutton(GLFWwindow* win, int btn, int act)
{
    (void)btn; (void)act;
    btn_left_  = (glfwGetMouseButton(win, GLFW_MOUSE_BUTTON_LEFT)   == GLFW_PRESS);
    btn_right_ = (glfwGetMouseButton(win, GLFW_MOUSE_BUTTON_RIGHT)  == GLFW_PRESS);
    btn_mid_   = (glfwGetMouseButton(win, GLFW_MOUSE_BUTTON_MIDDLE) == GLFW_PRESS);
    glfwGetCursorPos(win, &lastx_, &lasty_);
}

void Renderer::on_mousemove(GLFWwindow* win, double x, double y)
{
    if (!btn_left_ && !btn_right_ && !btn_mid_) return;
    const double dx = x - lastx_, dy = y - lasty_;
    lastx_ = x; lasty_ = y;

    int W, H;
    glfwGetWindowSize(win, &W, &H);
    if (x > W * SPLIT_X) return;   /* zona grafici: ignora */

    mjtMouse action;
    if      (btn_right_) action = mjMOUSE_MOVE_V;
    else if (btn_left_ && glfwGetKey(win, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
                         action = mjMOUSE_MOVE_H;
    else if (btn_left_)  action = mjMOUSE_ROTATE_V;
    else                 action = mjMOUSE_ZOOM;

    mjv_moveCamera(model_, action, dx/H, dy/H, &scn_, &cam_);
}

void Renderer::on_scroll(double yoff)
{
    mjv_moveCamera(model_, mjMOUSE_ZOOM, 0, -0.05*yoff, &scn_, &cam_);
}

/* ═══════════════════════════════════════════════════════════════
 *  Grafici — Inizializzazione
 * ═══════════════════════════════════════════════════════════════ */

void Renderer::init_fig_thrust()
{
    mjv_defaultFigure(&fig_thrust_);

    fig_thrust_.figurergba[0]=0.08f; fig_thrust_.figurergba[1]=0.08f;
    fig_thrust_.figurergba[2]=0.10f; fig_thrust_.figurergba[3]=0.95f;
    for (int k=0;k<3;k++) fig_thrust_.gridrgb[k]=0.3f;
    fig_thrust_.gridsize[0]=4; fig_thrust_.gridsize[1]=5;
    fig_thrust_.linewidth = 1.8f;

    std::snprintf(fig_thrust_.title,  sizeof(fig_thrust_.title),  "Thrust [N]");
    std::snprintf(fig_thrust_.xlabel, sizeof(fig_thrust_.xlabel), "t [s]");
    fig_thrust_.range[0][0] = -PLOT_HISTORY; fig_thrust_.range[0][1] = 0.0f;
    fig_thrust_.range[1][0] = 0.0f;          fig_thrust_.range[1][1] = 0.18f;

    static const char* names[] = {"f1 front","f2 left","f3 back","f4 right"};
    static const float cols[4][3] = {
        {0.95f,0.20f,0.20f}, {0.20f,0.85f,0.20f},
        {0.25f,0.55f,1.00f}, {1.00f,0.85f,0.10f}
    };
    for (int i=0;i<4;i++) {
        std::snprintf(fig_thrust_.linename[i],
                      sizeof(fig_thrust_.linename[i]), "%s", names[i]);
        for (int k=0;k<3;k++) fig_thrust_.linergb[i][k] = cols[i][k];
    }
}

void Renderer::init_fig_state()
{
    mjv_defaultFigure(&fig_state_);

    fig_state_.figurergba[0]=0.08f; fig_state_.figurergba[1]=0.08f;
    fig_state_.figurergba[2]=0.10f; fig_state_.figurergba[3]=0.95f;
    for (int k=0;k<3;k++) fig_state_.gridrgb[k]=0.3f;
    fig_state_.gridsize[0]=4; fig_state_.gridsize[1]=6;
    fig_state_.linewidth = 1.8f;

    std::snprintf(fig_state_.title,  sizeof(fig_state_.title),
                  "State  (rpy/10 deg)");
    std::snprintf(fig_state_.xlabel, sizeof(fig_state_.xlabel), "t [s]");
    fig_state_.range[0][0] = -PLOT_HISTORY; fig_state_.range[0][1] = 0.0f;
    fig_state_.range[1][0] = -0.5f;         fig_state_.range[1][1] = 1.5f;

    static const char* names[] = {"z [m]","z_des","roll/10 deg","pitch/10 deg"};
    static const float cols[4][3] = {
        {0.10f,0.90f,0.90f}, {0.65f,0.65f,0.65f},
        {1.00f,0.50f,0.10f}, {0.90f,0.20f,0.80f}
    };
    for (int i=0;i<4;i++) {
        std::snprintf(fig_state_.linename[i],
                      sizeof(fig_state_.linename[i]), "%s", names[i]);
        for (int k=0;k<3;k++) fig_state_.linergb[i][k] = cols[i][k];
    }
}

void Renderer::reset_plots()
{
    for (int i=0;i<4;i++) {
        fig_thrust_.linepnt[i] = 0;
        fig_state_.linepnt[i]  = 0;
    }
}

/* ═══════════════════════════════════════════════════════════════
 *  Grafici — Aggiornamento
 * ═══════════════════════════════════════════════════════════════ */

/*
 * fig_push()
 * ----------
 * Aggiunge val come punto più recente (x=0) e shifta
 * i precedenti verso x negativi di dt secondi.
 */
void Renderer::fig_push(mjvFigure& fig, int ln, float dt, float val)
{
    int pnt = fig.linepnt[ln];
    if (pnt < mjMAXLINEPNT) pnt++;

    /* Shift y verso indici più alti (più vecchi) */
    for (int i=pnt-1; i>0; i--)
        fig.linedata[ln][2*i+1] = fig.linedata[ln][2*(i-1)+1];

    /* Inserisci il nuovo valore */
    fig.linedata[ln][1] = val;

    /* Aggiorna le coordinate x: x[i] = -i*dt */
    for (int i=0; i<pnt; i++)
        fig.linedata[ln][2*i] = -(float)i * dt;

    fig.linepnt[ln] = pnt;
}

void Renderer::update_plots(const mjData* d, float dt_plot, double z_des)
{
    double q[4] = {d->qpos[3], d->qpos[4], d->qpos[5], d->qpos[6]};
    qmath::normalize(q);
    double roll, pitch, yaw;
    qmath::to_euler(q, roll, pitch, yaw);
    (void)yaw;

    const float z   = (float)d->qpos[2];
    const float rsc = (float)(roll  * 180.0/M_PI / 10.0);
    const float psc = (float)(pitch * 180.0/M_PI / 10.0);

    /* Grafico spinte */
    for (int i=0; i<4; i++)
        fig_push(fig_thrust_, i, dt_plot, (float)d->ctrl[i]);

    /* Grafico stato */
    fig_push(fig_state_, 0, dt_plot, z);
    fig_push(fig_state_, 1, dt_plot, (float)z_des);
    fig_push(fig_state_, 2, dt_plot, rsc);
    fig_push(fig_state_, 3, dt_plot, psc);
}

/* ═══════════════════════════════════════════════════════════════
 *  Rendering
 * ═══════════════════════════════════════════════════════════════ */

void Renderer::render_frame(const mjModel* m, mjData* d,
                             double x_des, double y_des, double z_des)
{
    int W, H;
    glfwGetFramebufferSize(win_, &W, &H);
    const int split = (int)(W * SPLIT_X);

    /* ── Scena 3D (sinistra) ──────────────────────────────────── */
    const mjrRect rect_3d = {0, 0, split, H};
    mjv_updateScene(m, d, &opt_, nullptr, &cam_, mjCAT_ALL, &scn_);
    mjr_render(rect_3d, &scn_, &ctx_);

    /* Overlay testo */
    {
        double q[4] = {d->qpos[3], d->qpos[4], d->qpos[5], d->qpos[6]};
        qmath::normalize(q);
        double roll, pitch, yaw;
        qmath::to_euler(q, roll, pitch, yaw);

        char buf[400];
        std::snprintf(buf, sizeof(buf),
            "t = %.2f s%s\n"
            "x = %+.3f m  (des %.2f)\n"
            "y = %+.3f m  (des %.2f)\n"
            "z = %+.3f m  (des %.2f)\n"
            "roll  = %+6.2f deg\n"
            "pitch = %+6.2f deg\n"
            "yaw   = %+6.2f deg\n"
            "\n[ESC] esci  [R] reset  [P] pausa",
            d->time, paused_ ? " [PAUSA]" : "",
            d->qpos[0], x_des,
            d->qpos[1], y_des,
            d->qpos[2], z_des,
            roll*180/M_PI, pitch*180/M_PI, yaw*180/M_PI);
        mjr_overlay(mjFONT_NORMAL, mjGRID_TOPLEFT, rect_3d, buf, nullptr, &ctx_);
    }

    /* ── Grafico thrust (destra, metà superiore) ──────────────── */
    const mjrRect rect_th = {split, H/2, W-split, H/2};
    mjr_figure(rect_th, &fig_thrust_, &ctx_);

    /* ── Grafico stato (destra, metà inferiore) ───────────────── */
    const mjrRect rect_st = {split, 0, W-split, H/2};
    mjr_figure(rect_st, &fig_state_, &ctx_);

    glfwSwapBuffers(win_);
    glfwPollEvents();
}

bool Renderer::should_close() const
{
    return win_ && glfwWindowShouldClose(win_);
}
