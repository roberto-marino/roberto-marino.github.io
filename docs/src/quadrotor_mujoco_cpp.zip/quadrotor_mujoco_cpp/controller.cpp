#include "controller.hpp"
#include "math_utils.hpp"
#include <algorithm>
#include <cmath>

void Controller::compute(const mjModel* m, mjData* d)
{
    (void)m;

    const double* pos  = d->qpos;       /* [x, y, z]         */
    const double* quat = d->qpos + 3;   /* [w, x, y, z]      */
    const double* vel  = d->qvel;       /* velocità in mondo  */
    const double* omg  = d->qvel + 3;   /* omega in mondo     */

    /* Orientazione */
    double q[4] = {quat[0], quat[1], quat[2], quat[3]};
    qmath::normalize(q);

    double roll, pitch, yaw;
    qmath::to_euler(q, roll, pitch, yaw);

    /* omega nel frame body: omega_b = R^T * omega_world */
    double R[3][3];
    qmath::to_rotmat(q, R);
    double omg_b[3] = {0, 0, 0};
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            omg_b[i] += R[j][i] * omg[j];   /* R[j][i] = R^T[i][j] */

    /* ── Loop altitudine ─────────────────────────────────────────
     * f_total = m*(g + Kp_z*e_z + Kd_z*e_vz)                    */
    double f_total = DRONE_MASS * (GRAVITY
                   + p_.Kp_z * (p_.z_des - pos[2])
                   + p_.Kd_z * (-vel[2]));
    f_total = std::max(0.0, f_total);

    /* ── Loop posizione x/y → setpoint di assetto ────────────────
     * Linearizzazione piccoli angoli:
     *   x'' ≈  g * theta   →   theta_des =  ax / g
     *   y'' ≈ -g * phi     →   phi_des   = -ay / g              */
    const double ax = p_.Kp_xy*(p_.x_des - pos[0]) + p_.Kd_xy*(-vel[0]);
    const double ay = p_.Kp_xy*(p_.y_des - pos[1]) + p_.Kd_xy*(-vel[1]);
    const double theta_des = std::clamp( ax/GRAVITY, -p_.max_tilt, p_.max_tilt);
    const double phi_des   = std::clamp(-ay/GRAVITY, -p_.max_tilt, p_.max_tilt);

    /* ── Loop assetto ─────────────────────────────────────────────
     * tau = Kp*(des - actual) - Kd*rate                          */
    const double tau_x = p_.Kp_roll  * (phi_des   - roll)                - p_.Kd_roll  * omg_b[0];
    const double tau_y = p_.Kp_pitch * (theta_des - pitch)               - p_.Kd_pitch * omg_b[1];
    const double tau_z = p_.Kp_yaw   * qmath::wrap_pi(p_.yaw_des - yaw)  - p_.Kd_yaw   * omg_b[2];

    /* ── Mixing: inversione analitica di Gamma (config "+") ───────
     * f1 = T/4 - tz/(4c) - ty/(2l)    front CW
     * f2 = T/4 + tz/(4c) + tx/(2l)    left  CCW
     * f3 = T/4 - tz/(4c) + ty/(2l)    back  CW
     * f4 = T/4 + tz/(4c) - tx/(2l)    right CCW                 */
    const double l = ARM_LENGTH, c = KM_KF;
    const double T4 = f_total * 0.25;

    auto sat = [](double v) { return std::clamp(v, 0.0, MAX_THRUST); };
    d->ctrl[0] = sat(T4 - tau_z/(4*c) - tau_y/(2*l));
    d->ctrl[1] = sat(T4 + tau_z/(4*c) + tau_x/(2*l));
    d->ctrl[2] = sat(T4 - tau_z/(4*c) + tau_y/(2*l));
    d->ctrl[3] = sat(T4 + tau_z/(4*c) - tau_x/(2*l));
}
