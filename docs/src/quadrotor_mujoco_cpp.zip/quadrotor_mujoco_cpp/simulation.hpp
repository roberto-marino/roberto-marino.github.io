#pragma once
#include <mujoco/mujoco.h>
#include <string>
#include <stdexcept>

/*
 * Simulation
 * ----------
 * Owns mjModel* e mjData*. Espone solo step() e reset().
 * La fisica è interamente delegata a mj_step() di MuJoCo.
 */
class Simulation {
public:
    explicit Simulation(const std::string& xml_path);
    ~Simulation();

    /* Non copiabile (owning resource) */
    Simulation(const Simulation&)            = delete;
    Simulation& operator=(const Simulation&) = delete;

    void step();
    void reset();

    /* Applica e memorizza una perturbazione iniziale di assetto.
     * Viene riapplicata automaticamente da reset(). */
    void set_perturbation(double roll_deg, double pitch_deg);

    mjModel*       model()       { return m_; }
    mjData*        data()        { return d_; }
    const mjModel* model() const { return m_; }
    const mjData*  data()  const { return d_; }
    double         time()  const { return d_->time; }

private:
    mjModel* m_ = nullptr;
    mjData*  d_ = nullptr;

    double perturb_roll_  = 0.0;   /* [deg] salvati per reset() */
    double perturb_pitch_ = 0.0;

    void apply_perturbation_internal();
};
