#pragma once
#include <cmath>
#include <algorithm>

/* Fallback per M_PI se non definito dal compilatore */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace qmath {

inline void normalize(double* q)
{
    double n = std::sqrt(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+q[3]*q[3]);
    if (n < 1e-12) { q[0]=1; q[1]=q[2]=q[3]=0; return; }
    for (int i=0;i<4;i++) q[i]/=n;
}

inline void to_euler(const double* q,
                     double& roll, double& pitch, double& yaw)
{
    const double w=q[0], x=q[1], y=q[2], z=q[3];
    roll  = std::atan2(2*(w*x+y*z),  1-2*(x*x+y*y));
    const double sp = 2*(w*y-z*x);
    pitch = std::fabs(sp)>=1.0 ? std::copysign(M_PI/2.0,sp) : std::asin(sp);
    yaw   = std::atan2(2*(w*z+x*y),  1-2*(y*y+z*z));
}

inline void to_rotmat(const double* q, double R[3][3])
{
    const double w=q[0], x=q[1], y=q[2], z=q[3];
    R[0][0]=1-2*(y*y+z*z); R[0][1]=2*(x*y-w*z); R[0][2]=2*(x*z+w*y);
    R[1][0]=2*(x*y+w*z);   R[1][1]=1-2*(x*x+z*z); R[1][2]=2*(y*z-w*x);
    R[2][0]=2*(x*z-w*y);   R[2][1]=2*(y*z+w*x);   R[2][2]=1-2*(x*x+y*y);
}

inline double wrap_pi(double a)
{
    while (a >  M_PI) a -= 2*M_PI;
    while (a < -M_PI) a += 2*M_PI;
    return a;
}

} // namespace qmath
