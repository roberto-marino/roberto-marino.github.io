#pragma once
#include <mujoco/mujoco.h>
#include <GLFW/glfw3.h>
#include <functional>
#include <string>

/*
 * Renderer
 * --------
 * Gestisce:
 *   • finestra GLFW
 *   • scena 3D MuJoCo (mjvScene / mjrContext)
 *   • due grafici scrolling (mjvFigure)
 *   • callback mouse/tastiera
 *
 * Interfaccia pubblica minimale:
 *   init()         — crea finestra + registra callbacks
 *   make_context() — crea mjvScene e mjrContext
 *   update_plots() — aggiunge un punto ai grafici
 *   render_frame() — disegna tutto e fa swap
 *   should_close() — true se l'utente ha chiuso la finestra
 *
 * on_reset: std::function impostata dal main, chiamata quando
 *   l'utente preme R (resetta simulazione + grafici).
 */
class Renderer {
public:
    static constexpr double SPLIT_X      = 0.65;   /* % schermo per la 3D  */
    static constexpr float  PLOT_HISTORY = 8.0f;   /* secondi di storia    */
    static constexpr double RENDER_HZ    = 60.0;

    Renderer();
    ~Renderer();

    Renderer(const Renderer&)            = delete;
    Renderer& operator=(const Renderer&) = delete;

    bool init(int w = 1600, int h = 900,
              const std::string& title = "Quadrotor Hover \xe2\x80\x94 MuJoCo");
    void make_context(const mjModel* m);

    void update_plots(const mjData* d, float dt_plot, double z_des);
    void render_frame(const mjModel* m, mjData* d,
                      double x_des, double y_des, double z_des);

    bool should_close() const;
    bool is_paused()    const { return paused_; }

    /* Callback impostata dal main per il reset della simulazione */
    std::function<void()> on_reset;

private:
    /* ── GLFW / MuJoCo state ────────────────────────────────────── */
    GLFWwindow*    win_      = nullptr;
    const mjModel* model_    = nullptr;   /* per mjv_moveCamera      */
    mjvCamera      cam_;
    mjvOption      opt_;
    mjvScene       scn_;
    mjrContext     ctx_;
    mjvFigure      fig_thrust_;
    mjvFigure      fig_state_;

    /* ── Flags ───────────────────────────────────────────────────── */
    bool paused_    = false;
    bool glfw_ok_   = false;
    bool scene_ok_  = false;
    bool ctx_ok_    = false;

    /* ── Mouse state ─────────────────────────────────────────────── */
    int    btn_left_  = 0, btn_right_ = 0, btn_mid_ = 0;
    double lastx_     = 0, lasty_     = 0;

    /* ── GLFW callbacks (statiche, usano glfwGetWindowUserPointer) ─ */
    static void cb_keyboard   (GLFWwindow*, int, int, int, int);
    static void cb_mousebutton(GLFWwindow*, int, int, int);
    static void cb_mousemove  (GLFWwindow*, double, double);
    static void cb_scroll     (GLFWwindow*, double, double);

    /* ── Handler di istanza ─────────────────────────────────────── */
    void on_keyboard   (int key, int act);
    void on_mousebutton(GLFWwindow* w, int btn, int act);
    void on_mousemove  (GLFWwindow* w, double x, double y);
    void on_scroll     (double yoff);

    /* ── Grafici ─────────────────────────────────────────────────── */
    void init_fig_thrust();
    void init_fig_state();
    void reset_plots();
    static void fig_push(mjvFigure& fig, int ln, float dt, float val);
};
