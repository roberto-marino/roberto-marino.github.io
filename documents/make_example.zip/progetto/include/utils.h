#ifndef UTILS_H
#define UTILS_H

/* Restituisce la lunghezza di una stringa */
int my_strlen(const char *s);

/* Stampa una stringa n volte */
void stampa_n_volte(const char *s, int n);

#endif
