#ifndef PARSER_H
#define PARSER_H

/* Converte la stringa s in un intero.
   Restituisce -1 se la stringa non e' un numero valido. */
int parse_intero(const char *s);

#endif
