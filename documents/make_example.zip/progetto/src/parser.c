#include "parser.h"

int parse_intero(const char *s) {
    int risultato = 0;
    int i = 0;

    if (s[0] == '\0') return -1;

    while (s[i] != '\0') {
        if (s[i] < '0' || s[i] > '9') return -1;
        risultato = risultato * 10 + (s[i] - '0');
        i++;
    }
    return risultato;
}
