#include <stdio.h>
#include "utils.h"

int my_strlen(const char *s) {
    int i = 0;
    while (s[i] != '\0') i++;
    return i;
}

void stampa_n_volte(const char *s, int n) {
    for (int i = 0; i < n; i++)
        printf("%s\n", s);
}
