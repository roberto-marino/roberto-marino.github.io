#include <stdio.h>
#include "utils.h"
#include "parser.h"

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Uso: %s <parola> <numero>\n", argv[0]);
        printf("Esempio: %s ciao 3\n", argv[0]);
        return 1;
    }

    const char *parola = argv[1];
    int n = parse_intero(argv[2]);

    if (n < 0) {
        printf("Errore: '%s' non e' un numero valido.\n", argv[2]);
        return 1;
    }

    printf("Lunghezza di '%s': %d\n", parola, my_strlen(parola));
    printf("Stampo '%s' %d volte:\n", parola, n);
    stampa_n_volte(parola, n);

    return 0;
}
