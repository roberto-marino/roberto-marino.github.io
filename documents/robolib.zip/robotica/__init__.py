"""
robotica
========
Libreria minimale per Cinematica e Dinamica dei Robot.
Dipendenze: numpy, scipy, matplotlib  +  (opzionale) autograd, ipywidgets.

Moduli
------
transforms  : Rx, Ry, Rz, mdh_matrix, rpy2R, R2rpy, quat2R, R2quat, skew, vex
kinematics  : robot_2R, robot_3R, robot_puma560, fk, fk_all,
              jacobian, jacobian_autograd, manipulability,
              ikine_2R_analytical, ikine_numerical,
              jtraj, jtraj_multi, ctraj
dynamics    : inertia_matrix, coriolis_matrix, gravity_vector,
              inverse_dynamics, newton_euler,
              forward_dynamics, simulate
control     : pd_control, PIDController,
              computed_torque, computed_torque_factory
viz         : plot2d, plot_trajectory2d, animate2d,
              plot3d, plot_trajectory3d, animate3d,
              widget, trajectory_widget
"""

from .transforms import (Rx, Ry, Rz, T_from_Rp, Tx, Ty, Tz,
                          TRx, TRy, TRz, T_inv, mdh_matrix,
                          rpy2R, R2rpy, quat2R, R2quat, slerp,
                          skew, vex)

from .kinematics import (make_link, make_robot,
                          robot_2R, robot_3R, robot_puma560,
                          fk, fk_all,
                          jacobian, jacobian_com, jacobian_autograd,
                          manipulability,
                          ikine_2R_analytical, ikine_numerical,
                          jtraj, jtraj_multi, ctraj)

from .dynamics  import (inertia_matrix, coriolis_matrix, gravity_vector,
                         inverse_dynamics, newton_euler,
                         forward_dynamics, simulate)

from .control   import (pd_control, PIDController,
                         computed_torque, computed_torque_factory)

from .viz       import (plot2d, plot_trajectory2d, animate2d,
                         plot3d, plot_trajectory3d, animate3d,
                         widget, trajectory_widget)

__version__ = '1.0.0'
