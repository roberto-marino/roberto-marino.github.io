"""
viz.py
======
Visualizzazione 2D/3D, animazioni e widget ipywidgets.
Dipendenze: numpy, matplotlib, (opzionale) ipywidgets.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.animation import FuncAnimation
from .kinematics import fk_all, manipulability

# Palette
C = dict(link='#2196F3', joint='#FF5722', ee='#4CAF50',
         base='#455A64', traj='#FF9800',
         fx='#F44336', fy='#43A047', fz='#1565C0')

# ──────────────────────────────────────────────────────────────
# Utilità interne
# ──────────────────────────────────────────────────────────────

def _pts2d(robot, q):
    """Coordinate 2D di tutti i frame [base, link1, ..., EE]."""
    return np.array([T[:2,3] for T in fk_all(robot, q)])

def _pts3d(robot, q):
    """Coordinate 3D di tutti i frame."""
    return np.array([T[:3,3] for T in fk_all(robot, q)])

def _is_planar(robot):
    return all(abs(l['alpha']) < 1e-6 or
               abs(abs(l['alpha']) - np.pi) < 1e-6
               for l in robot['links'])

# ──────────────────────────────────────────────────────────────
# 1. Visualizzazione 2D
# ──────────────────────────────────────────────────────────────

def plot2d(robot, q=None, ax=None, title=None,
           show_frames=False, show_workspace=False,
           link_lw=6, joint_r=0.035, figsize=(7,7)):
    """
    Visualizza un robot planare in configurazione q.

    Parameters
    ----------
    show_frames    : bool – mostra assi dei frame (x rosso, y verde)
    show_workspace : bool – cerchio del workspace massimo
    link_lw        : float – spessore dei link
    joint_r        : float – raggio dei cerchi dei giunti [m]
    """
    if q is None:
        q = np.zeros(robot['n'])
    q = np.asarray(q, float)

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.get_figure()

    pts = _pts2d(robot, q)
    x, y = pts[:,0], pts[:,1]

    # Workspace (approssimazione: raggio = somma lunghezze link)
    if show_workspace:
        L = sum(abs(l['a']) for l in robot['links'])
        ax.add_patch(plt.Circle((0,0), L,
                                 color='#E3F2FD', zorder=0))

    # Link
    for i in range(len(pts)-1):
        ax.plot([x[i],x[i+1]], [y[i],y[i+1]],
                color=C['link'], lw=link_lw,
                solid_capstyle='round', zorder=2)

    # Giunti
    for i in range(robot['n']):
        col = C['joint']
        ax.add_patch(plt.Circle((x[i+1],y[i+1]), joint_r,
                                  color=col, zorder=3))

    # Base
    bx, by = x[0], y[0]
    ax.add_patch(plt.Polygon(
        [[bx-.06,by-.05],[bx+.06,by-.05],[bx,by]],
        color=C['base'], zorder=2))
    ax.plot([bx-.09,bx+.09], [by-.05,by-.05],
            color=C['base'], lw=3)

    # End-effector
    ax.plot(x[-1], y[-1], 's', color=C['ee'],
            ms=9, zorder=4, label='EE')
    ax.annotate(f"({x[-1]:.3f}, {y[-1]:.3f})",
                (x[-1],y[-1]), fontsize=8, color=C['ee'],
                xytext=(7,7), textcoords='offset points',
                bbox=dict(boxstyle='round,pad=0.2', fc='white', alpha=.7))

    # Frame dei giunti (assi x, y)
    if show_frames:
        Ts = fk_all(robot, q)
        sc = 0.07
        for T in Ts[1:-1]:
            ox, oy = T[0,3], T[1,3]
            ax.annotate('', xy=(ox+sc*T[0,0], oy+sc*T[1,0]),
                        xytext=(ox,oy),
                        arrowprops=dict(arrowstyle='->', color=C['fx'], lw=1.5))
            ax.annotate('', xy=(ox+sc*T[0,1], oy+sc*T[1,1]),
                        xytext=(ox,oy),
                        arrowprops=dict(arrowstyle='->', color=C['fy'], lw=1.5))

    # Formattazione
    m = 0.2
    ax.set_xlim(x.min()-m, x.max()+m)
    ax.set_ylim(y.min()-m, y.max()+m)
    ax.set_aspect('equal')
    ax.grid(True, alpha=.3)
    ax.axhline(0, color='gray', lw=.5, alpha=.5)
    ax.axvline(0, color='gray', lw=.5, alpha=.5)
    ax.set_xlabel('x [m]')
    ax.set_ylabel('y [m]')
    q_str = ', '.join([f'{np.degrees(qi):.1f}°' for qi in q])
    ax.set_title(title or f"{robot['name']}   q=[{q_str}]", fontsize=11)
    plt.tight_layout()
    return fig, ax


def plot_trajectory2d(robot, Q, ax=None, n_poses=8,
                       title=None, figsize=(9,6)):
    """
    Visualizza una traiettoria 2D: percorso EE + n_poses pose fantasma.
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.get_figure()

    # Percorso EE
    ee = np.array([_pts2d(robot, Q[k])[-1] for k in range(len(Q))])
    ax.plot(ee[:,0], ee[:,1], '--', color=C['traj'], lw=2, alpha=.8,
            label='Percorso EE')
    ax.plot(*ee[ 0], 'o', color='green', ms=8, label='Start', zorder=5)
    ax.plot(*ee[-1], 's', color='red',   ms=8, label='End',   zorder=5)

    # Pose fantasma
    for idx in np.linspace(0, len(Q)-1, n_poses, dtype=int):
        pts = _pts2d(robot, Q[idx])
        for i in range(len(pts)-1):
            ax.plot([pts[i,0],pts[i+1,0]],[pts[i,1],pts[i+1,1]],
                    color=C['link'], lw=3, alpha=.18)

    # Posa finale
    plot2d(robot, Q[-1], ax=ax, show_frames=False)
    ax.legend(fontsize=9)
    if title: ax.set_title(title)
    return fig, ax


def animate2d(robot, Q, t=None, dt_ms=50,
              figsize=(7,7), show_trail=True):
    """
    Animazione 2D.
    Restituisce un oggetto FuncAnimation.
    In Jupyter:  from IPython.display import HTML; HTML(anim.to_jshtml())
    """
    fig, ax = plt.subplots(figsize=figsize)
    all_pts = np.vstack([_pts2d(robot, Q[k]) for k in range(len(Q))])
    m = .2
    ax.set_xlim(all_pts[:,0].min()-m, all_pts[:,0].max()+m)
    ax.set_ylim(all_pts[:,1].min()-m, all_pts[:,1].max()+m)
    ax.set_aspect('equal'); ax.grid(True, alpha=.3)
    ax.set_xlabel('x [m]'); ax.set_ylabel('y [m]')

    lines   = [ax.plot([],[],color=C['link'],lw=5,
                       solid_capstyle='round')[0] for _ in range(robot['n'])]
    joints  = [plt.Circle((0,0),.03,color=C['joint'],zorder=3)
                for _ in range(robot['n'])]
    for c in joints: ax.add_patch(c)
    ee_dot, = ax.plot([],[],  's', color=C['ee'], ms=9, zorder=4)
    trail,  = ax.plot([],[],  '--',color=C['traj'], lw=1.5, alpha=.5)
    ttext   = ax.text(.02,.95,'', transform=ax.transAxes, fontsize=10)
    trail_x, trail_y = [], []

    def update(k):
        pts = _pts2d(robot, Q[k])
        for i in range(robot['n']):
            lines[i].set_data([pts[i,0],pts[i+1,0]],
                               [pts[i,1],pts[i+1,1]])
            joints[i].center = (pts[i+1,0], pts[i+1,1])
        trail_x.append(pts[-1,0]); trail_y.append(pts[-1,1])
        if show_trail: trail.set_data(trail_x, trail_y)
        ee_dot.set_data([pts[-1,0]], [pts[-1,1]])
        ttext.set_text(f't={t[k]:.2f}s' if t is not None else f'#{k}')
        return lines + [trail, ee_dot, ttext] + joints

    return FuncAnimation(fig, update, frames=len(Q),
                         interval=dt_ms, blit=False)


# ──────────────────────────────────────────────────────────────
# 2. Visualizzazione 3D
# ──────────────────────────────────────────────────────────────

def plot3d(robot, q=None, ax=None, title=None,
           show_frames=True, frame_scale=0.07, figsize=(9,7)):
    """
    Visualizza un robot 3D nella configurazione q.
    """
    from mpl_toolkits.mplot3d import Axes3D
    if q is None:
        q = np.zeros(robot['n'])
    q = np.asarray(q, float)

    if ax is None:
        fig = plt.figure(figsize=figsize)
        ax  = fig.add_subplot(111, projection='3d')
    else:
        fig = ax.get_figure()

    pts = _pts3d(robot, q)
    Ts  = fk_all(robot, q)

    # Link
    for i in range(len(pts)-1):
        ax.plot3D(*zip(pts[i], pts[i+1]),
                  color=C['link'], lw=4, solid_capstyle='round')

    # Giunti
    for i, lnk in enumerate(robot['links']):
        col = C['joint'] if lnk['type']=='R' else '#9C27B0'
        ax.scatter(*pts[i+1], color=col, s=70, depthshade=False, zorder=4)

    # EE e base
    ax.scatter(*pts[-1], color=C['ee'], s=110, marker='*',
               depthshade=False, zorder=5, label='EE')
    ax.scatter(*pts[0],  color=C['base'], s=80, marker='s',
               depthshade=False, zorder=5, label='Base')

    # Frame
    if show_frames:
        sc = frame_scale
        fc = [C['fx'], C['fy'], C['fz']]
        for T in Ts[1:]:
            o = T[:3,3]
            for j in range(3):
                ax.quiver(*o, *(T[:3,j]*sc), color=fc[j],
                          lw=1.5, arrow_length_ratio=.3)

    # Range automatico
    c = pts.mean(axis=0)
    r = max(pts.ptp(axis=0).max()*.6, 0.4) + .1
    ax.set_xlim(c[0]-r,c[0]+r); ax.set_ylim(c[1]-r,c[1]+r)
    ax.set_zlim(c[2]-r,c[2]+r)
    ax.set_xlabel('X [m]'); ax.set_ylabel('Y [m]'); ax.set_zlabel('Z [m]')
    ax.grid(True, alpha=.3); ax.legend(fontsize=9)
    q_str = ', '.join([f'{np.degrees(qi):.1f}°' for qi in q])
    ax.set_title(title or f"{robot['name']}\nq=[{q_str}]", fontsize=10)
    plt.tight_layout()
    return fig, ax


def plot_trajectory3d(robot, Q, ax=None, n_poses=6,
                       title=None, figsize=(9,7)):
    """Visualizza traiettoria 3D con percorso EE e pose intermedie."""
    from mpl_toolkits.mplot3d import Axes3D
    if ax is None:
        fig = plt.figure(figsize=figsize)
        ax  = fig.add_subplot(111, projection='3d')
    else:
        fig = ax.get_figure()

    ee = np.array([_pts3d(robot,Q[k])[-1] for k in range(len(Q))])
    ax.plot3D(*ee.T, '--', color=C['traj'], lw=2, alpha=.8, label='EE path')
    ax.scatter(*ee[ 0], color='green', s=80, zorder=5, label='Start')
    ax.scatter(*ee[-1], color='red',   s=80, zorder=5, label='End')

    for idx in np.linspace(0,len(Q)-1,n_poses,dtype=int):
        pts = _pts3d(robot,Q[idx])
        for i in range(len(pts)-1):
            ax.plot3D(*zip(pts[i],pts[i+1]),
                      color=C['link'], lw=3, alpha=.18)

    plot3d(robot, Q[-1], ax=ax, show_frames=False)
    ax.legend(fontsize=9)
    if title: ax.set_title(title)
    return fig, ax


def animate3d(robot, Q, t=None, dt_ms=50, figsize=(9,7)):
    """Animazione 3D."""
    from mpl_toolkits.mplot3d import Axes3D
    fig = plt.figure(figsize=figsize)
    ax  = fig.add_subplot(111, projection='3d')

    all_pts = np.vstack([_pts3d(robot,Q[k]) for k in range(len(Q))])
    c = all_pts.mean(axis=0)
    r = max(all_pts.ptp(axis=0).max()*.6, 0.4)+.1
    ax.set_xlim(c[0]-r,c[0]+r); ax.set_ylim(c[1]-r,c[1]+r)
    ax.set_zlim(c[2]-r,c[2]+r)
    ax.set_xlabel('X'); ax.set_ylabel('Y'); ax.set_zlabel('Z')

    lines  = [ax.plot3D([],[],[],color=C['link'],lw=4)[0]
              for _ in range(robot['n'])]
    trail, = ax.plot3D([],[],[], '--', color=C['traj'], lw=1.5, alpha=.6)
    tx, ty, tz = [], [], []
    ttext = ax.text2D(.02,.95,'', transform=ax.transAxes)

    def update(k):
        pts = _pts3d(robot,Q[k])
        for i in range(robot['n']):
            lines[i].set_data([pts[i,0],pts[i+1,0]],
                               [pts[i,1],pts[i+1,1]])
            lines[i].set_3d_properties([pts[i,2],pts[i+1,2]])
        tx.append(pts[-1,0]); ty.append(pts[-1,1]); tz.append(pts[-1,2])
        trail.set_data(tx,ty); trail.set_3d_properties(tz)
        ttext.set_text(f't={t[k]:.2f}s' if t is not None else f'#{k}')
        return lines+[trail,ttext]

    return FuncAnimation(fig, update, frames=len(Q),
                         interval=dt_ms, blit=False)


# ──────────────────────────────────────────────────────────────
# 3. Widget ipywidgets
# ──────────────────────────────────────────────────────────────

def widget(robot, figsize=None, show_frames=False, show_workspace=False):
    """
    Widget interattivo Jupyter: uno slider per giunto.
    Richiede: pip install ipywidgets

    Uso:
        from robotica.viz import widget
        widget(robot)
    """
    try:
        import ipywidgets as iw
        from IPython.display import display
    except ImportError:
        raise ImportError("Installa ipywidgets:  pip install ipywidgets")

    is_p = _is_planar(robot)
    if figsize is None:
        figsize = (7,7) if is_p else (9,7)

    sliders = []
    for i, lnk in enumerate(robot['links']):
        qmin, qmax = lnk['qlim']
        if lnk['type'] == 'R':
            s = iw.FloatSlider(value=0., min=np.degrees(qmin),
                               max=np.degrees(qmax), step=1.,
                               description=f'q{i+1}[°]',
                               layout=iw.Layout(width='460px'),
                               style={'description_width':'60px'})
        else:
            s = iw.FloatSlider(value=0., min=qmin, max=qmax, step=.01,
                               description=f'd{i+1}[m]',
                               layout=iw.Layout(width='460px'),
                               style={'description_width':'60px'})
        sliders.append(s)

    out = iw.Output()

    def update(**kw):
        q_vals = []
        for i, lnk in enumerate(robot['links']):
            v = kw[f'q{i}']
            q_vals.append(np.radians(v) if lnk['type']=='R' else v)
        with out:
            out.clear_output(wait=True)
            if is_p:
                fig, ax = plot2d(robot, q_vals, figsize=figsize,
                                 show_frames=show_frames,
                                 show_workspace=show_workspace)
            else:
                fig, ax = plot3d(robot, q_vals, figsize=figsize,
                                 show_frames=show_frames)
            T_ee = fk_all(robot, q_vals)[-1]
            p    = T_ee[:3,3]
            w    = manipulability(robot, q_vals)
            info = (f"EE = ({p[0]:.3f}, {p[1]:.3f}"
                    + (f")" if is_p else f", {p[2]:.3f})")
                    + f"   manipolabilità = {w:.4f}")
            if is_p:
                ax.set_xlabel(f'x [m]\n{info}', fontsize=9)
            else:
                ax.set_title(info, fontsize=9)
            plt.show()

    slider_dict = {f'q{i}': s for i, s in enumerate(sliders)}
    iw.interactive_output(update, slider_dict)

    title = iw.HTML(f"<b>🤖 {robot['name']} – Cinematica Interattiva</b>")
    ui    = iw.VBox([title] + sliders + [out])
    display(ui)
    update(**{k: s.value for k,s in slider_dict.items()})
    return ui


def trajectory_widget(robot, Q, t=None, figsize=None):
    """
    Widget per riprodurre una traiettoria frame-per-frame.
    Richiede: pip install ipywidgets
    """
    try:
        import ipywidgets as iw
        from IPython.display import display
    except ImportError:
        raise ImportError("Installa ipywidgets:  pip install ipywidgets")

    is_p = _is_planar(robot)
    if figsize is None:
        figsize = (7,7) if is_p else (9,7)
    N = len(Q)

    slider = iw.IntSlider(value=0, min=0, max=N-1, step=1,
                           description='Frame:',
                           layout=iw.Layout(width='500px'))
    play   = iw.Play(value=0, min=0, max=N-1, step=1,
                     interval=50, description='▶')
    iw.jslink((play,'value'), (slider,'value'))
    out = iw.Output()

    def update(frame):
        with out:
            out.clear_output(wait=True)
            if is_p:
                fig, ax = plot2d(robot, Q[frame], figsize=figsize)
                ee_past = np.array([_pts2d(robot,Q[k])[-1]
                                     for k in range(frame+1)])
                ax.plot(ee_past[:,0], ee_past[:,1], '--',
                        color=C['traj'], alpha=.6, lw=1.5)
            else:
                fig, ax = plot3d(robot, Q[frame], figsize=figsize,
                                  show_frames=False)
            tinfo = f"  t={t[frame]:.2f}s" if t is not None else f"  #{frame}"
            if is_p:
                ax.set_title(f"{robot['name']}{tinfo}")
            plt.show()

    iw.interactive_output(update, {'frame': slider})
    ui = iw.VBox([
        iw.HTML(f"<b>▶ Traiettoria – {robot['name']}</b>"),
        iw.HBox([play, slider]),
        out
    ])
    display(ui); update(0)
    return ui
