"""
dynamics.py
===========
Dinamica Lagrangiana e algoritmo di Newton-Euler ricorsivo.
Dipendenze: numpy, (opzionale) autograd.

Approccio Khalil (Lagrangiana tramite Jacobiani dei link)
---------------------------------------------------------
L'energia cinetica totale è:

    T(q, dq) = ½ dqᵀ M(q) dq

dove la matrice di inerzia si calcola come:

    M(q) = Σᵢ [ mᵢ Jvᵢᵀ Jvᵢ  +  Jωᵢᵀ ⁰Iᵢ Jωᵢ ]

con Jvᵢ, Jωᵢ = Jacobiani del CoM del link i,
    ⁰Iᵢ = Rᵢ Iᵢ Rᵢᵀ  = tensore di inerzia ruotato nel frame base.

La matrice di Coriolis/centrifuga viene calcolata tramite i
simboli di Christoffel di 2ª specie:

    cᵢⱼₖ = ½ (∂Mᵢⱼ/∂qₖ + ∂Mᵢₖ/∂qⱼ - ∂Mⱼₖ/∂qᵢ)
    Cᵢⱼ  = Σₖ cᵢⱼₖ dqₖ

Le derivate parziali di M sono calcolate via:
  • autograd.jacobian(M_func)   se autograd è installato  → esatte
  • differenze finite centrate   altrimenti                → approssimate

Il vettore gravitazionale è:

    G(q) = -Σᵢ mᵢ Jvᵢᵀ g₀

Riferimento: Khalil & Dombre, Cap. 9.
"""

import numpy as np
from .kinematics import fk_all, jacobian_com

# ── tenta autograd ─────────────────────────────────────────────
try:
    import autograd.numpy as anp
    from autograd import jacobian as _ag_jac
    _AUTOGRAD = True
except ImportError:
    _AUTOGRAD = False

G0_DEFAULT = np.array([0., 0., -9.81])   # gravità standard [m/s²]

# ──────────────────────────────────────────────────────────────
# 1. Matrici M, C, G  (approccio Lagrange–Khalil)
# ──────────────────────────────────────────────────────────────

def inertia_matrix(robot, q):
    """
    Matrice di inerzia M(q)  (n × n).

    M(q) = Σᵢ [ mᵢ Jvᵢᵀ Jvᵢ  +  Jωᵢᵀ (Rᵢ Iᵢ Rᵢᵀ) Jωᵢ ]

    Parameters
    ----------
    robot : dict
    q     : (n,) array

    Returns
    -------
    M : (n, n) ndarray  (simmetrica, definita positiva)
    """
    q  = np.asarray(q, float)
    n  = robot['n']
    M  = np.zeros((n, n))
    Ts = fk_all(robot, q)

    for i, link in enumerate(robot['links']):
        if link['m'] == 0.:
            continue
        Jci = jacobian_com(robot, q, i)
        Jv  = Jci[:3, :]
        Jw  = Jci[3:, :]
        R_i = Ts[i+1][:3, :3]
        I0  = R_i @ link['I'] @ R_i.T       # inerzia nel frame base
        M  += link['m'] * (Jv.T @ Jv) + Jw.T @ I0 @ Jw

    return M


def _dM_dq(robot, q):
    """
    Tensore ∂M/∂q  di forma (n, n, n):
        dM[i,j,k] = ∂M_{ij} / ∂q_k

    Se autograd è disponibile, usa differenziazione automatica (esatta).
    Altrimenti usa differenze finite centrate.
    """
    q = np.asarray(q, float)
    n = robot['n']

    if _AUTOGRAD:
        # autograd richiede che la funzione usi anp al posto di np.
        # Riscriviamo M(q) in forma compatibile con autograd.
        def M_autograd(q_):
            M_ = anp.zeros((n, n))
            Ts_ = fk_all(robot, q_)      # fk_all usa numpy standard
            # Nota: fk_all usa numpy, quindi autograd traccia solo attraverso q_.
            # Per la piena differenziabilità usiamo la versione "recomputed" qui sotto.
            for i, link in enumerate(robot['links']):
                if link['m'] == 0.:
                    continue
                Jci = _jac_com_ag(robot, q_, i, Ts_)
                Jv  = Jci[:3, :]
                Jw  = Jci[3:, :]
                R_i = Ts_[i+1][:3, :3]
                I0  = R_i @ link['I'] @ R_i.T
                M_  = M_ + link['m']*(Jv.T @ Jv) + Jw.T @ I0 @ Jw
            return M_

        # _ag_jac(M_autograd) differenzia M rispetto al suo argomento (q)
        # Risultato shape: (n, n, n) con dM[i,j,k] = ∂M_ij/∂q_k
        dM_fn = _ag_jac(M_autograd)
        dM    = dM_fn(q)                  # (n, n, n)
        # autograd restituisce ∂M/∂q con shape (n,n,n): dM[i,j,k] = ∂M_{ij}/∂q_k? No.
        # autograd.jacobian di funzione f:(n,)→(n,n) restituisce shape (n,n,n)
        # con dM[i,j,k] = ∂M_{ij}/∂q_k   ← k è l'indice di q
        return np.array(dM)

    else:
        # Differenze finite centrate  O(h²)
        eps = 1e-6
        dM  = np.zeros((n, n, n))
        for k in range(n):
            qp = q.copy(); qp[k] += eps
            qm = q.copy(); qm[k] -= eps
            dM[:, :, k] = (inertia_matrix(robot, qp) -
                           inertia_matrix(robot, qm)) / (2*eps)
        return dM


def _jac_com_ag(robot, q_, i, Ts_):
    """
    Versione autograd-compatibile di jacobian_com per il link i.
    Usa anp per le operazioni che dipendono da q_.
    """
    n     = robot['n']
    T_i   = Ts_[i+1]
    p_com = T_i[:3,:3] @ robot['links'][i]['r_com'] + T_i[:3,3]

    rows_v = []
    rows_w = []
    for j in range(n):
        T_j = Ts_[j]
        z_j = T_j[:3, 2]
        p_j = T_j[:3, 3]
        lnk = robot['links'][j]
        if j <= i:
            if lnk['type'] == 'R':
                rows_v.append(anp.cross(z_j, p_com - p_j))
                rows_w.append(z_j)
            else:
                rows_v.append(z_j)
                rows_w.append(anp.zeros(3))
        else:
            rows_v.append(anp.zeros(3))
            rows_w.append(anp.zeros(3))

    Jv = anp.stack(rows_v, axis=1)   # (3, n)
    Jw = anp.stack(rows_w, axis=1)
    return anp.concatenate([Jv, Jw], axis=0)   # (6, n)


def coriolis_matrix(robot, q, dq):
    """
    Matrice di Coriolis/centrifuga C(q, dq)  (n × n).

    Calcolata tramite i simboli di Christoffel di 2ª specie:

        cᵢⱼₖ = ½ (∂Mᵢⱼ/∂qₖ  +  ∂Mᵢₖ/∂qⱼ  -  ∂Mⱼₖ/∂qᵢ)
        Cᵢⱼ  = Σₖ cᵢⱼₖ dqₖ

    La coppia di Coriolis è poi:  τ_c = C(q,dq) dq

    Con autograd le derivate ∂M/∂q sono esatte;
    senza autograd si usano differenze finite O(h²).

    Returns
    -------
    C : (n, n) ndarray
    """
    q  = np.asarray(q,  float)
    dq = np.asarray(dq, float)
    n  = robot['n']
    dM = _dM_dq(robot, q)          # (n, n, n):  dM[i,j,k] = ∂M_{ij}/∂q_k

    C = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            for k in range(n):
                # Christoffel: c_{ijk} = ½(∂M_ij/∂q_k + ∂M_ik/∂q_j - ∂M_jk/∂q_i)
                c_ijk = 0.5*(dM[i,j,k] + dM[i,k,j] - dM[j,k,i])
                C[i,j] += c_ijk * dq[k]
    return C


def gravity_vector(robot, q, g0=None):
    """
    Vettore gravitazionale G(q)  (n,).

        G(q) = -Σᵢ mᵢ Jvᵢ(q)ᵀ g₀

    Parameters
    ----------
    g0 : (3,) vettore gravità nel frame base (default [0,0,-9.81])
    """
    q  = np.asarray(q, float)
    if g0 is None:
        g0 = G0_DEFAULT
    g0 = np.asarray(g0, float)
    n  = robot['n']
    G  = np.zeros(n)

    for i, link in enumerate(robot['links']):
        if link['m'] == 0.:
            continue
        Jci = jacobian_com(robot, q, i)
        G  -= link['m'] * Jci[:3,:].T @ g0

    return G

# ──────────────────────────────────────────────────────────────
# 2. Dinamica inversa  τ = M ddq + C dq + G
# ──────────────────────────────────────────────────────────────

def inverse_dynamics(robot, q, dq, ddq, g0=None):
    """
    Coppia necessaria per seguire la traiettoria (q, dq, ddq).

        τ = M(q) ddq  +  C(q,dq) dq  +  G(q)

    Returns
    -------
    tau : (n,) ndarray  [N·m  o  N]
    """
    q   = np.asarray(q,   float)
    dq  = np.asarray(dq,  float)
    ddq = np.asarray(ddq, float)
    M = inertia_matrix(robot, q)
    C = coriolis_matrix(robot, q, dq)
    G = gravity_vector(robot, q, g0)
    return M @ ddq + C @ dq + G

# ──────────────────────────────────────────────────────────────
# 3. Algoritmo di Newton-Euler ricorsivo  (Khalil Cap. 9)
# ──────────────────────────────────────────────────────────────

def newton_euler(robot, q, dq, ddq, g0=None, f_tip=None, n_tip=None):
    """
    Algoritmo di Newton-Euler ricorsivo in due passate.

    Passata avanti (forward): propaga velocità e accelerazioni
        dal base verso l'end-effector.

    Passata indietro (backward): propaga forze e momenti
        dall'end-effector verso il base.

    Parameters
    ----------
    q, dq, ddq  : (n,) array – configurazione, velocità, accelerazione
    g0          : (3,)  vettore gravità nel frame base
    f_tip, n_tip: (3,)  forza e momento esterni all'EE

    Returns
    -------
    tau : (n,) ndarray – coppie/forze ai giunti
    """
    q   = np.asarray(q,   float)
    dq  = np.asarray(dq,  float)
    ddq = np.asarray(ddq, float)
    if g0    is None: g0    = G0_DEFAULT
    if f_tip is None: f_tip = np.zeros(3)
    if n_tip is None: n_tip = np.zeros(3)

    n     = robot['n']
    links = robot['links']
    ez    = np.array([0., 0., 1.])   # asse z locale

    # Precomputa matrici DH relative
    R_rel = []   # R_{i-1,i}  = T_{i-1}^i [:3,:3]
    p_rel = []   # p_{i-1,i}  = T_{i-1}^i [:3, 3]
    from .transforms import mdh_matrix
    for i, lnk in enumerate(links):
        Ti = mdh_matrix(lnk['alpha'], lnk['a'],
                        lnk['d'] if lnk['type']=='R' else lnk['d']+lnk['offset']+q[i],
                        lnk['theta']+lnk['offset']+q[i] if lnk['type']=='R' else lnk['theta']+lnk['offset'])
        R_rel.append(Ti[:3,:3])
        p_rel.append(Ti[:3, 3])

    # ── Passata avanti ──────────────────────────────────────────
    omega  = [np.zeros(3)] * (n+1)    # velocità angolare
    domega = [np.zeros(3)] * (n+1)    # accelerazione angolare
    ddp    = [np.zeros(3)] * (n+1)    # acc. lineare origine frame
    ddpc   = [None] * n               # acc. lineare CoM

    omega[0]  = np.zeros(3)
    domega[0] = np.zeros(3)
    ddp[0]    = -np.asarray(g0, float)   # include effetto gravità

    for i, lnk in enumerate(links):
        Ri = R_rel[i];  pi = p_rel[i];  Rt = Ri.T   # Rt porta da i-1 a i

        if lnk['type'] == 'R':
            omega[i+1]  = Rt @ omega[i]  +  dq[i]*ez
            domega[i+1] = (Rt @ domega[i]
                           + ddq[i]*ez
                           + np.cross(Rt @ omega[i], dq[i]*ez))
        else:
            omega[i+1]  = Rt @ omega[i]
            domega[i+1] = Rt @ domega[i]

        ddp[i+1] = Rt @ (np.cross(domega[i], pi)
                         + np.cross(omega[i], np.cross(omega[i], pi))
                         + ddp[i])
        if lnk['type'] == 'P':
            ddp[i+1] += ddq[i]*ez + 2.*np.cross(omega[i+1], dq[i]*ez)

        rc = lnk['r_com']
        ddpc[i] = (ddp[i+1]
                   + np.cross(domega[i+1], rc)
                   + np.cross(omega[i+1], np.cross(omega[i+1], rc)))

    # ── Passata indietro ────────────────────────────────────────
    f = [None]*(n+1);  m = [None]*(n+1)
    f[n] = np.asarray(f_tip, float)
    m[n] = np.asarray(n_tip, float)
    tau  = np.zeros(n)

    for i in range(n-1, -1, -1):
        lnk = links[i]
        pi  = p_rel[i]                 # p_{i-1→i}  nel frame i
        rc  = lnk['r_com']
        mi  = lnk['m']
        Ii  = lnk['I']

        # Trasporta la forza/momento dal frame i+1 al frame i
        if i < n-1:
            f_next = R_rel[i+1] @ f[i+1]
            m_next = R_rel[i+1] @ m[i+1]
        else:
            f_next = f[n]
            m_next = m[n]

        # Vettore dall'origine del frame i all'origine del frame i+1,
        # espresso nel frame i.
        # In MDH: p_rel[i+1] = T_{i}^{i+1}[:3,3] è già nel frame i → usa direttamente.
        p_i_to_next = p_rel[i+1] if i < n-1 else np.zeros(3)

        # Equazione di Newton:  F_i = m_i * a_{c_i} + F_{i+1}
        f[i] = mi * ddpc[i] + f_next

        # Equazione di Euler (Khalil eq. 9.24):
        # M_i = I_i α_i + ω_i × (I_i ω_i)           [inerzia angolare del link i]
        #     + r_{c_i} × (m_i a_{c_i})               [momento dovuto all'acc. del CoM]
        #     + p_{i→i+1} × F_{i+1}                   [momento dovuto alla forza al giunto i+1]
        #     + M_{i+1}                                [momento trasmesso dal link i+1]
        m[i] = (Ii @ domega[i+1]
                + np.cross(omega[i+1], Ii @ omega[i+1])
                + np.cross(rc,         mi * ddpc[i])
                + np.cross(p_i_to_next, f_next)
                + m_next)

        tau[i] = (m[i] @ ez) if lnk['type']=='R' else (f[i] @ ez)

    return tau

# ──────────────────────────────────────────────────────────────
# 4. Dinamica diretta + simulazione ODE
# ──────────────────────────────────────────────────────────────

def forward_dynamics(robot, q, dq, tau, g0=None):
    """
    ddq = M(q)⁻¹ (τ  -  C(q,dq) dq  -  G(q))

    Returns
    -------
    ddq : (n,) ndarray
    """
    q   = np.asarray(q,  float)
    dq  = np.asarray(dq, float)
    tau = np.asarray(tau,float)
    M = inertia_matrix(robot, q)
    C = coriolis_matrix(robot, q, dq)
    G = gravity_vector(robot, q, g0)
    return np.linalg.solve(M, tau - C @ dq - G)


def simulate(robot, q0, dq0, tau_func, T=5.0, dt=0.01, g0=None, method='RK4'):
    """
    Simula la dinamica diretta con integrazione numerica.

    Parameters
    ----------
    q0, dq0   : (n,) stato iniziale
    tau_func  : callable(t, q, dq) → (n,) – legge di controllo
    T         : float – durata [s]
    dt        : float – passo di integrazione [s]
    method    : 'RK4' (default) oppure 'Euler' (più semplice, meno accurato)

    Returns
    -------
    dict con chiavi:  't', 'q', 'dq', 'tau'

    Nota: RK4 implementato a mano (senza scipy) per renderlo trasparente.
    """
    q0  = np.asarray(q0,  float)
    dq0 = np.asarray(dq0, float)
    n   = robot['n']
    t   = np.arange(0, T + dt/2, dt)
    N   = len(t)

    Q   = np.zeros((N, n))
    DQ  = np.zeros((N, n))
    TAU = np.zeros((N, n))

    Q[0]  = q0
    DQ[0] = dq0

    def derivs(t_, q_, dq_):
        tau_ = tau_func(t_, q_, dq_)
        ddq_ = forward_dynamics(robot, q_, dq_, tau_, g0)
        return dq_, ddq_, tau_

    for k in range(N-1):
        tk, qk, dqk = t[k], Q[k], DQ[k]
        tau_k = tau_func(tk, qk, dqk)
        TAU[k] = tau_k

        if method == 'Euler':
            ddq = forward_dynamics(robot, qk, dqk, tau_k, g0)
            Q[k+1]  = qk  + dt * dqk
            DQ[k+1] = dqk + dt * ddq

        else:   # RK4 classico
            # k1
            dq1, ddq1, _ = derivs(tk,        qk,          dqk)
            # k2
            dq2, ddq2, _ = derivs(tk+dt/2,   qk+dt/2*dq1, dqk+dt/2*ddq1)
            # k3
            dq3, ddq3, _ = derivs(tk+dt/2,   qk+dt/2*dq2, dqk+dt/2*ddq2)
            # k4
            dq4, ddq4, _ = derivs(tk+dt,     qk+dt*dq3,   dqk+dt*ddq3)

            Q[k+1]  = qk  + dt/6*(dq1  + 2*dq2  + 2*dq3  + dq4)
            DQ[k+1] = dqk + dt/6*(ddq1 + 2*ddq2 + 2*ddq3 + ddq4)

    TAU[-1] = tau_func(t[-1], Q[-1], DQ[-1])
    return {'t': t, 'q': Q, 'dq': DQ, 'tau': TAU}
