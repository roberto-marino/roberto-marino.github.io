"""
control.py
==========
Leggi di controllo per robot seriali nello spazio dei giunti.
Dipendenze: solo numpy + dynamics.py.

Leggi implementate
------------------
1. PD   : τ = Kp(q_d - q) + Kd(dq_d - dq)
2. PID  : τ = Kp e + Ki ∫e dt + Kd ė     (con anti-windup)
3. Coppia Calcolata (Computed Torque / Feedback Linearization):
          τ = M(q)[ddq_d + Kd ė + Kp e] + C(q,dq)dq + G(q)
   → linearizza esattamente la dinamica → errore soddisfa:
          ë + Kd ė + Kp e = 0   (sistema lineare del 2° ordine)

Riferimento: Khalil & Dombre, Cap. 11.
"""

import numpy as np
from .dynamics import inertia_matrix, coriolis_matrix, gravity_vector

# ──────────────────────────────────────────────────────────────
# 1. PD
# ──────────────────────────────────────────────────────────────

def pd_control(q, dq, q_d, dq_d, Kp, Kd):
    """
    Legge di controllo PD:

        τ = Kp (q_d - q)  +  Kd (dq_d - dq)

    Parameters
    ----------
    q, dq       : (n,) – stato corrente
    q_d, dq_d   : (n,) – stato desiderato
    Kp, Kd      : (n,) o (n,n) – guadagni (scalari, vettori diagonale o matrici)

    Returns
    -------
    tau : (n,) ndarray
    """
    q   = np.asarray(q,   float)
    dq  = np.asarray(dq,  float)
    q_d = np.asarray(q_d, float)
    dq_d = np.asarray(dq_d,float) if dq_d is not None else np.zeros_like(q)
    n   = len(q)
    Kp  = _to_matrix(Kp, n)
    Kd  = _to_matrix(Kd, n)
    return Kp @ (q_d - q) + Kd @ (dq_d - dq)


# ──────────────────────────────────────────────────────────────
# 2. PID  (con anti-windup)
# ──────────────────────────────────────────────────────────────

class PIDController:
    """
    Controllore PID nello spazio dei giunti.

        τ = Kp e  +  Ki ∫e dt  +  Kd ė

    L'integrale viene limitato a [-i_max, i_max] (anti-windup).

    Parameters
    ----------
    Kp, Ki, Kd : (n,) o scalare – guadagni
    dt         : float – passo di campionamento [s]
    i_max      : float – limite anti-windup
    """

    def __init__(self, Kp, Ki, Kd, dt=0.01, i_max=10.):
        self.Kp    = np.atleast_1d(np.asarray(Kp, float))
        self.Ki    = np.atleast_1d(np.asarray(Ki, float))
        self.Kd    = np.atleast_1d(np.asarray(Kd, float))
        self.dt    = dt
        self.i_max = i_max
        self._integral = None

    def reset(self):
        """Azzera lo stato interno."""
        self._integral = None

    def __call__(self, q, dq, q_d, dq_d=None):
        q   = np.asarray(q,  float)
        q_d = np.asarray(q_d,float)
        n   = len(q)
        if dq_d is None:
            dq_d = np.zeros(n)
        if self._integral is None:
            self._integral = np.zeros(n)

        e  = q_d - q
        de = np.asarray(dq_d, float) - np.asarray(dq, float)

        self._integral = np.clip(self._integral + e*self.dt,
                                  -self.i_max, self.i_max)
        return self.Kp*e + self.Ki*self._integral + self.Kd*de


# ──────────────────────────────────────────────────────────────
# 3. Coppia Calcolata  (Computed Torque)
# ──────────────────────────────────────────────────────────────

def computed_torque(robot, q, dq, q_d, dq_d, ddq_d, Kp, Kd, g0=None):
    """
    Legge di controllo a coppia calcolata (Khalil, eq. 11.x):

        τ = M(q) v  +  C(q,dq) dq  +  G(q)

    dove  v = ddq_d + Kd(dq_d - dq) + Kp(q_d - q)  è il termine di feedforward+feedback.

    Con questa legge l'equazione dell'errore diventa:
        ë  +  Kd ė  +  Kp e = 0
    → sistema lineare del 2° ordine: stabilità garantita se
      Kp, Kd > 0.  Scelta critica: Kd = 2√Kp  (smorzamento critico).

    Parameters
    ----------
    robot            : dict
    q, dq            : (n,) – stato corrente
    q_d, dq_d, ddq_d : (n,) – traiettoria desiderata
    Kp, Kd           : (n,) o (n,n)

    Returns
    -------
    tau : (n,) ndarray
    """
    q    = np.asarray(q,    float)
    dq   = np.asarray(dq,   float)
    q_d  = np.asarray(q_d,  float)
    dq_d = np.asarray(dq_d, float)
    ddq_d= np.asarray(ddq_d,float)
    n    = len(q)
    Kp   = _to_matrix(Kp, n)
    Kd   = _to_matrix(Kd, n)

    e   = q_d  - q
    de  = dq_d - dq
    v   = ddq_d + Kd @ de + Kp @ e    # termine "virtuale" lineare

    M = inertia_matrix(robot,  q)
    C = coriolis_matrix(robot, q, dq)
    G = gravity_vector(robot,  q, g0)

    return M @ v + C @ dq + G


def computed_torque_factory(robot, Kp, Kd, traj_func, g0=None):
    """
    Restituisce una funzione tau(t, q, dq) pronta per essere passata
    a dynamics.simulate().

    Parameters
    ----------
    traj_func : callable(t) → (q_d, dq_d, ddq_d)
                Funzione che restituisce la traiettoria desiderata al tempo t.

    Returns
    -------
    tau_fn : callable(t, q, dq) → (n,)
    """
    def tau_fn(t, q, dq):
        q_d, dq_d, ddq_d = traj_func(t)
        return computed_torque(robot, q, dq, q_d, dq_d, ddq_d, Kp, Kd, g0)
    return tau_fn


# ──────────────────────────────────────────────────────────────
# Utilità interna
# ──────────────────────────────────────────────────────────────

def _to_matrix(K, n):
    """Converte scalare / vettore diagonale → matrice n×n."""
    K = np.asarray(K, float)
    if K.ndim == 0:
        return float(K) * np.eye(n)
    if K.ndim == 1:
        return np.diag(K) if len(K)==n else K[0]*np.eye(n)
    return K
