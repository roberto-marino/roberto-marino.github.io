"""
transforms.py
=============
Trasformazioni geometriche fondamentali.
Dipendenze: solo numpy.

Convenzioni
-----------
* Matrici di rotazione  R : (3,3)
* Matrici omogenee      T : (4,4)
* Angoli RPY (roll, pitch, yaw) = rotazione ZYX intrinseca
  R = Rz(yaw) @ Ry(pitch) @ Rx(roll)
* Quaternioni q = [w, x, y, z]  (parte scalare prima)

Riferimento: Khalil & Dombre, Cap. 1-2.
"""

import numpy as np

# ──────────────────────────────────────────────────────────────
# 1. Rotazioni elementari
# ──────────────────────────────────────────────────────────────

def Rx(a):
    """Rotazione di a [rad] attorno all'asse X."""
    c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0,  0],
                     [0, c, -s],
                     [0, s,  c]], dtype=float)

def Ry(a):
    """Rotazione di a [rad] attorno all'asse Y."""
    c, s = np.cos(a), np.sin(a)
    return np.array([[ c, 0, s],
                     [ 0, 1, 0],
                     [-s, 0, c]], dtype=float)

def Rz(a):
    """Rotazione di a [rad] attorno all'asse Z."""
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0],
                     [s,  c, 0],
                     [0,  0, 1]], dtype=float)

# ──────────────────────────────────────────────────────────────
# 2. Matrici omogenee
# ──────────────────────────────────────────────────────────────

def T_from_Rp(R, p=None):
    """
    Matrice omogenea 4x4 da rotazione R (3x3) e posizione p (3,).
    Se p è None → traslazione nulla.
    """
    T = np.eye(4)
    T[:3, :3] = R
    if p is not None:
        T[:3, 3] = np.asarray(p).ravel()
    return T

def Tx(d): return T_from_Rp(np.eye(3), [d, 0, 0])
def Ty(d): return T_from_Rp(np.eye(3), [0, d, 0])
def Tz(d): return T_from_Rp(np.eye(3), [0, 0, d])

def TRx(a): return T_from_Rp(Rx(a))
def TRy(a): return T_from_Rp(Ry(a))
def TRz(a): return T_from_Rp(Rz(a))

def T_inv(T):
    """
    Inversa efficiente di una matrice omogenea.
    Sfrutta la struttura:  T^{-1} = [ R^T | -R^T p ]
                                     [  0  |    1   ]
    """
    R = T[:3, :3]
    p = T[:3,  3]
    Ti = np.eye(4)
    Ti[:3, :3] =  R.T
    Ti[:3,  3] = -R.T @ p
    return Ti

# ──────────────────────────────────────────────────────────────
# 3. Parametri MDH → matrice T  (Khalil & Dombre eq. 1.x)
# ──────────────────────────────────────────────────────────────

def mdh_matrix(alpha, a, d, theta):
    """
    Matrice di trasformazione MDH (Modified DH, Khalil):

        T_{i-1}^{i} = Rx(alpha) @ Tx(a) @ Rz(theta) @ Tz(d)

    In forma chiusa:
        | ct      -st       0       a      |
        | st*ca   ct*ca   -sa     -d*sa    |
        | st*sa   ct*sa    ca      d*ca    |
        |  0        0       0       1      |

    dove ct=cos(theta), st=sin(theta), ca=cos(alpha), sa=sin(alpha).

    Parameters
    ----------
    alpha, a     : torsione e distanza lungo x_{i-1}
    d, theta     : distanza e rotazione lungo/attorno z_i
    """
    ct, st = np.cos(theta), np.sin(theta)
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array([
        [ct,     -st,      0,     a    ],
        [st*ca,   ct*ca,  -sa,   -d*sa ],
        [st*sa,   ct*sa,   ca,    d*ca ],
        [0,       0,       0,     1    ],
    ], dtype=float)

# ──────────────────────────────────────────────────────────────
# 4. Angoli RPY
# ──────────────────────────────────────────────────────────────

def rpy2R(roll, pitch, yaw):
    """
    R = Rz(yaw) @ Ry(pitch) @ Rx(roll)   (convenzione ZYX intrinseca)
    """
    return Rz(yaw) @ Ry(pitch) @ Rx(roll)

def R2rpy(R):
    """
    Estrae (roll, pitch, yaw) da R.
    Restituisce un array [roll, pitch, yaw] in radianti.
    Attenzione: singolarità per pitch = ±90° (gimbal lock).
    """
    pitch = np.arctan2(-R[2, 0], np.sqrt(R[0,0]**2 + R[1,0]**2))
    if np.abs(np.cos(pitch)) > 1e-10:
        roll = np.arctan2(R[2, 1], R[2, 2])
        yaw  = np.arctan2(R[1, 0], R[0, 0])
    else:                          # gimbal lock
        roll = 0.0
        yaw  = np.arctan2(-R[0, 1], R[1, 1])
    return np.array([roll, pitch, yaw])

# ──────────────────────────────────────────────────────────────
# 5. Quaternioni  q = [w, x, y, z]
# ──────────────────────────────────────────────────────────────

def quat2R(q):
    """
    Quaternione [w, x, y, z] → matrice di rotazione 3×3.
    Il quaternione viene normalizzato automaticamente.
    """
    q = np.asarray(q, dtype=float)
    q = q / np.linalg.norm(q)
    w, x, y, z = q
    return np.array([
        [1 - 2*(y*y + z*z),   2*(x*y - w*z),       2*(x*z + w*y)],
        [2*(x*y + w*z),       1 - 2*(x*x + z*z),   2*(y*z - w*x)],
        [2*(x*z - w*y),       2*(y*z + w*x),       1 - 2*(x*x + y*y)],
    ])

def R2quat(R):
    """
    Matrice di rotazione → quaternione [w, x, y, z].
    Algoritmo di Shepperd (stabile numericamente).
    """
    tr = R[0,0] + R[1,1] + R[2,2]
    if tr > 0:
        s = 0.5 / np.sqrt(tr + 1.0)
        w = 0.25 / s
        x = (R[2,1] - R[1,2]) * s
        y = (R[0,2] - R[2,0]) * s
        z = (R[1,0] - R[0,1]) * s
    elif R[0,0] > R[1,1] and R[0,0] > R[2,2]:
        s = 2.0 * np.sqrt(1.0 + R[0,0] - R[1,1] - R[2,2])
        w = (R[2,1] - R[1,2]) / s;  x = 0.25 * s
        y = (R[0,1] + R[1,0]) / s;  z = (R[0,2] + R[2,0]) / s
    elif R[1,1] > R[2,2]:
        s = 2.0 * np.sqrt(1.0 + R[1,1] - R[0,0] - R[2,2])
        w = (R[0,2] - R[2,0]) / s;  y = 0.25 * s
        x = (R[0,1] + R[1,0]) / s;  z = (R[1,2] + R[2,1]) / s
    else:
        s = 2.0 * np.sqrt(1.0 + R[2,2] - R[0,0] - R[1,1])
        w = (R[1,0] - R[0,1]) / s;  z = 0.25 * s
        x = (R[0,2] + R[2,0]) / s;  y = (R[1,2] + R[2,1]) / s
    q = np.array([w, x, y, z])
    return q / np.linalg.norm(q)

def slerp(q0, q1, t):
    """
    SLERP (Spherical Linear Interpolation) tra quaternioni.
    t ∈ [0,1]: t=0 → q0,  t=1 → q1.
    """
    q0 = np.asarray(q0, dtype=float)
    q1 = np.asarray(q1, dtype=float)
    dot = np.clip(np.dot(q0, q1), -1.0, 1.0)
    if dot < 0:                    # sceglie il percorso più breve
        q1, dot = -q1, -dot
    if dot > 0.9995:               # quasi uguali → lerp lineare
        return (q0 + t*(q1 - q0)) / np.linalg.norm(q0 + t*(q1 - q0))
    theta0 = np.arccos(dot)
    theta  = theta0 * t
    return (np.sin(theta0 - theta)*q0 + np.sin(theta)*q1) / np.sin(theta0)

# ──────────────────────────────────────────────────────────────
# 6. Operatori vettoriali
# ──────────────────────────────────────────────────────────────

def skew(v):
    """
    Matrice antisimmetrica di v  (operatore prodotto vettoriale):
        skew(v) @ u  ≡  v × u
    """
    v = np.asarray(v).ravel()
    return np.array([
        [ 0,    -v[2],  v[1]],
        [ v[2],  0,    -v[0]],
        [-v[1],  v[0],  0   ],
    ], dtype=float)

def vex(S):
    """
    Estrae il vettore assiale da una matrice antisimmetrica S.
    Inverso di skew().
    """
    return np.array([S[2,1], S[0,2], S[1,0]])
