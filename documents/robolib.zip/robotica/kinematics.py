"""
kinematics.py
=============
Cinematica diretta, inversa, Jacobiano e traiettorie.
Dipendenze: numpy, (opzionale) autograd.

Il Jacobiano viene calcolato in DUE modi:
  1. Geometrico  – formula analitica esplicita (sempre disponibile)
  2. Analitico   – via autograd.jacobian sulla FK (se autograd è installato)
     → ottimo per verificare i calcoli a mano e come esercizio didattico

Struttura dati – Robot
----------------------
Un robot è un dizionario con chiavi:

    'n'          : int               numero di giunti
    'links'      : list[dict]        parametri di ogni link (vedi sotto)
    'T_base'     : ndarray (4,4)     trasformazione mondo→base  (default: I)
    'T_tool'     : ndarray (4,4)     trasformazione ultimo_giunto→EE  (default: I)

Ogni link è un dizionario:
    'alpha'      : float   [rad]  torsione MDH
    'a'          : float   [m]    distanza MDH
    'd'          : float   [m]    distanza MDH  (fisso per R, variabile per P)
    'theta'      : float   [rad]  angolo MDH    (fisso per P, variabile per R)
    'type'       : str            'R' (rotoidale) o 'P' (prismatico)
    'offset'     : float          offset sul parametro variabile
    'qlim'       : (float,float)  limiti del giunto
    'm'          : float   [kg]   massa del link
    'r_com'      : ndarray (3,)   CoM nel frame del link
    'I'          : ndarray (3,3)  tensore inerzia nel CoM [kg·m²]

Riferimento: Khalil & Dombre, Cap. 2-3.
"""

import numpy as np
from .transforms import mdh_matrix, skew, vex, R2rpy, T_from_Rp, R2quat, quat2R, slerp
from scipy.interpolate import CubicSpline

# ── tenta di importare autograd ────────────────────────────────
try:
    import autograd.numpy as anp
    from autograd import jacobian as _ag_jacobian
    _AUTOGRAD = True
except ImportError:
    _AUTOGRAD = False

# ──────────────────────────────────────────────────────────────
# 1. Costruttori di robot predefiniti
# ──────────────────────────────────────────────────────────────

def make_link(alpha=0., a=0., d=0., theta=0., joint_type='R',
              offset=0., qlim=(-np.pi, np.pi),
              m=0., r_com=None, I=None, name=''):
    """Crea un dizionario-link con parametri MDH."""
    return {
        'alpha': float(alpha), 'a': float(a),
        'd':     float(d),     'theta': float(theta),
        'type':  joint_type,   'offset': float(offset),
        'qlim':  qlim,
        'm':     float(m),
        'r_com': np.zeros(3) if r_com is None else np.asarray(r_com, float),
        'I':     np.zeros((3,3)) if I is None else np.asarray(I, float),
        'name':  name,
    }

def make_robot(links, name='Robot', T_base=None, T_tool=None):
    """Assembla un robot dal dizionario dei link."""
    return {
        'n':      len(links),
        'links':  links,
        'name':   name,
        'T_base': np.eye(4) if T_base is None else np.asarray(T_base, float),
        'T_tool': np.eye(4) if T_tool is None else np.asarray(T_tool, float),
    }

# Robot predefiniti ─────────────────────────────────────────────

def robot_2R(L1=0.5, L2=0.3, m1=1.0, m2=0.5):
    """
    Robot planare 2R (parametri MDH Khalil).

    Catena MDH:
      Link1: alpha=0, a=0,  d=0, theta=q1  → giunto 1 in origine
      Link2: alpha=0, a=L1, d=0, theta=q2  → giunto 2 a distanza L1 da giunto 1
      T_tool: Tx(L2)                         → punta del link 2

    Posizione EE: p = L1[cos q1, sin q1] + L2[cos(q1+q2), sin(q1+q2)]
    """
    def Ibar(m, L):
        return np.diag([0., 0., m*L**2/12])
    links = [
        make_link(alpha=0, a=0,  d=0, theta=0, joint_type='R',
                  m=m1, r_com=[L1/2,0,0], I=Ibar(m1,L1), name='Link1'),
        make_link(alpha=0, a=L1, d=0, theta=0, joint_type='R',
                  m=m2, r_com=[L2/2,0,0], I=Ibar(m2,L2), name='Link2'),
    ]
    from .transforms import Tx
    r = make_robot(links, name=f'2R (L1={L1}, L2={L2})',
                   T_tool=Tx(L2))
    r['L1'], r['L2'] = L1, L2
    return r

def robot_3R(L1=0.4, L2=0.3, L3=0.2, m1=1., m2=.8, m3=.4):
    """Robot planare 3R ridondante."""
    def Ibar(m, L):
        return np.diag([0., 0., m*L**2/12])
    links = [
        make_link(alpha=0, a=0,  d=0, theta=0, joint_type='R',
                  m=m1, r_com=[L1/2,0,0], I=Ibar(m1,L1), name='Link1'),
        make_link(alpha=0, a=L1, d=0, theta=0, joint_type='R',
                  m=m2, r_com=[L2/2,0,0], I=Ibar(m2,L2), name='Link2'),
        make_link(alpha=0, a=L2, d=0, theta=0, joint_type='R',
                  m=m3, r_com=[L3/2,0,0], I=Ibar(m3,L3), name='Link3'),
    ]
    from .transforms import Tx
    r = make_robot(links, name='3R planare', T_tool=Tx(L3))
    r['L1'], r['L2'], r['L3'] = L1, L2, L3
    return r

def robot_puma560():
    """
    Puma 560 – parametri MDH da Khalil & Dombre, Appendice A.
    """
    d = np.pi/2
    masses = [0.0, 17.4, 4.8, 0.82, 0.34, 0.09]
    rcoms  = [[0,0,0],[0,.068,.006],[0,.006,-.016],
              [0,0,-.019],[0,0,0],[0,0,.032]]
    Is_diag = [[0,0,.35],[.13,.524,.539],[.066,.0125,.066],
               [.0018,.0018,.00033],[.0003,.0003,.0004],[.0001,.0001,.0001]]
    qlims = [(-np.radians(160), np.radians(160)),
             (-np.radians(45),  np.radians(225)),
             (-np.radians(225), np.radians(45)),
             (-np.radians(110), np.radians(170)),
             (-np.radians(100), np.radians(100)),
             (-np.radians(266), np.radians(266))]
    dh = [( 0,  0,      0,      0),
          (-d,  0,      0,      0),
          ( 0,  0.4318, 0.1501, 0),
          (-d, -0.0203, 0.4331, 0),
          ( d,  0,      0,      0),
          (-d,  0,      0,      0)]
    links = [
        make_link(alpha=dh[i][0], a=dh[i][1], d=dh[i][2], theta=dh[i][3],
                  joint_type='R', qlim=qlims[i],
                  m=masses[i], r_com=rcoms[i], I=np.diag(Is_diag[i]),
                  name=f'Link{i+1}')
        for i in range(6)
    ]
    return make_robot(links, name='Puma 560')

# ──────────────────────────────────────────────────────────────
# 2. Cinematica diretta (FK)
# ──────────────────────────────────────────────────────────────

def _link_T(link, qi):
    """
    Matrice omogenea MDH del link per il valore del giunto qi.
    Giunto R: theta = theta_0 + offset + qi
    Giunto P: d     = d_0     + offset + qi
    """
    if link['type'] == 'R':
        theta = link['theta'] + link['offset'] + qi
        d     = link['d']
    else:
        theta = link['theta'] + link['offset']
        d     = link['d'] + link['offset'] + qi
    return mdh_matrix(link['alpha'], link['a'], d, theta)

def fk(robot, q):
    """
    Cinematica diretta: T_0^{EE}(q) = T_base * T_0^1 * ... * T_{n-1}^n * T_tool

    Parameters
    ----------
    robot : dict  – struttura robot
    q     : (n,) array – configurazione giunti

    Returns
    -------
    T : (4,4) ndarray – posa end-effector nel frame mondo
    """
    q = np.asarray(q, dtype=float)
    T = robot['T_base'].copy()
    for i, link in enumerate(robot['links']):
        T = T @ _link_T(link, q[i])
    return T @ robot['T_tool']

def fk_all(robot, q):
    """
    Restituisce la lista di tutte le pose intermedie:
    [T_base, T_0^1, T_0^2, ..., T_0^n, T_EE]
    Utile per visualizzazione e calcolo del Jacobiano.
    """
    q = np.asarray(q, dtype=float)
    Ts = [robot['T_base'].copy()]
    T  = robot['T_base'].copy()
    for i, link in enumerate(robot['links']):
        T = T @ _link_T(link, q[i])
        Ts.append(T.copy())
    Ts.append(Ts[-1] @ robot['T_tool'])
    return Ts

# ──────────────────────────────────────────────────────────────
# 3. Jacobiano geometrico  (formula esplicita, Khalil Cap. 3)
# ──────────────────────────────────────────────────────────────

def jacobian(robot, q):
    """
    Jacobiano geometrico J_0(q)  di dimensione (6 × n).

    Colonna i-esima (frame base):
      Giunto R:  J_v = z_{i-1} × (p_EE - p_{i-1})   J_ω = z_{i-1}
      Giunto P:  J_v = z_{i-1}                        J_ω = 0

    dove z_{i-1} è il terzo asse della matrice di orientazione T_0^{i-1}.

    Returns
    -------
    J : (6, n) ndarray
        Righe 0:3 → velocità lineare,  righe 3:6 → velocità angolare
    """
    q  = np.asarray(q, dtype=float)
    n  = robot['n']
    Ts = fk_all(robot, q)           # lista di n+2 matrici (ultima include T_tool)
    p_ee = Ts[-1][:3, 3]           # posizione end-effector (con T_tool)
    J  = np.zeros((6, n))

    for i, link in enumerate(robot['links']):
        # In MDH Khalil:
        # - l'ASSE del giunto i è l'asse z del frame PRECEDENTE: Ts[i]
        # - l'ORIGINE del giunto i è Ts[i+1] (dopo la traslazione a_i nel link i+1)
        z_i = Ts[i][:3, 2]            # asse z del frame i-1
        p_i = Ts[i+1][:3, 3]          # origine del giunto i (dopo traslazione a)

        if link['type'] == 'R':
            J[:3, i] = np.cross(z_i, p_ee - p_i)   # v
            J[3:, i] = z_i                           # ω
        else:
            J[:3, i] = z_i
            J[3:, i] = np.zeros(3)

    return J

def jacobian_com(robot, q, i):
    """
    Jacobiano (6×n) per il centro di massa del link i (0-based).
    Usato dalla dinamica Lagrangiana.
    """
    q  = np.asarray(q, dtype=float)
    n  = robot['n']
    Ts = fk_all(robot, q)

    # Posizione del CoM del link i nel frame base
    T_i   = Ts[i+1]
    p_com = T_i[:3, :3] @ robot['links'][i]['r_com'] + T_i[:3, 3]

    J = np.zeros((6, n))
    for j in range(i+1):
        # In MDH Khalil: asse z del giunto j = Ts[j][:3,2]
        #                origine del giunto j = Ts[j+1][:3,3]
        z_j = Ts[j][:3, 2]
        p_j = Ts[j+1][:3, 3]
        lnk = robot['links'][j]
        if lnk['type'] == 'R':
            J[:3, j] = np.cross(z_j, p_com - p_j)
            J[3:, j] = z_j
        else:
            J[:3, j] = z_j
    return J

# ──────────────────────────────────────────────────────────────
# 3b. Jacobiano via autograd  (se disponibile)
# ──────────────────────────────────────────────────────────────

def jacobian_autograd(robot, q):
    """
    Jacobiano della posizione EE calcolato via autograd.jacobian.
    Restituisce solo la parte lineare (3×n).

    Richiede: pip install autograd
    Utile come verifica del jacobiano geometrico (dovrebbero coincidere).
    """
    if not _AUTOGRAD:
        raise ImportError("autograd non è installato. "
                          "Esegui: pip install autograd")

    def p_ee(q_):
        """Posizione EE come funzione di q (usando anp per compatibilità autograd)."""
        T = anp.eye(4)
        for i, link in enumerate(robot['links']):
            a  = link['alpha']
            ai = link['a']
            if link['type'] == 'R':
                th = link['theta'] + link['offset'] + q_[i]
                d  = link['d']
            else:
                th = link['theta'] + link['offset']
                d  = link['d'] + link['offset'] + q_[i]
            ct, st = anp.cos(th), anp.sin(th)
            ca, sa = anp.cos(a),  anp.sin(a)
            Ti = anp.array([
                [ct,     -st,      0.,     ai   ],
                [st*ca,   ct*ca,  -sa,    -d*sa ],
                [st*sa,   ct*sa,   ca,     d*ca ],
                [0.,      0.,      0.,     1.   ],
            ])
            T = T @ Ti
        return T[:3, 3]

    Jv = _ag_jacobian(p_ee)(np.asarray(q, dtype=float))
    return Jv   # (3, n)


def manipulability(robot, q, kind='yoshikawa'):
    """
    Indice di manipolabilità nella configurazione q.

    kind = 'yoshikawa' : w = sqrt(det(Jv @ Jv^T))    (Yoshikawa 1985)
           'condition'  : w = σ_min / σ_max
           'minimum'    : w = σ_min
    """
    Jv = jacobian(robot, q)[:3, :]
    sv = np.linalg.svd(Jv, compute_uv=False)
    if kind == 'yoshikawa':
        return float(np.sqrt(max(0, np.linalg.det(Jv @ Jv.T))))
    elif kind == 'condition':
        return float(sv[-1]/sv[0]) if sv[0] > 1e-12 else 0.
    elif kind == 'minimum':
        return float(sv[-1])
    raise ValueError(f"kind='{kind}' non riconosciuto")

# ──────────────────────────────────────────────────────────────
# 4. Cinematica inversa
# ──────────────────────────────────────────────────────────────

def ikine_2R_analytical(robot, x, y, elbow='up'):
    """
    Soluzione analitica chiusa per il robot 2R planare.

    Formule:
        c2 = (x² + y² - L1² - L2²) / (2 L1 L2)
        s2 = ±√(1 - c2²)
        q2 = atan2(s2, c2)
        q1 = atan2(y,x) - atan2(L2 s2,  L1 + L2 c2)

    Parameters
    ----------
    elbow : 'up' | 'down'   (s2 > 0 | s2 < 0)

    Returns
    -------
    q : (2,) array  oppure None se il punto è fuori workspace.
    """
    L1, L2 = robot['L1'], robot['L2']
    c2 = (x**2 + y**2 - L1**2 - L2**2) / (2*L1*L2)
    if abs(c2) > 1.0:
        print(f"⚠  Punto ({x:.3f}, {y:.3f}) fuori workspace (|c2|={abs(c2):.3f})")
        return None
    s2 = np.sqrt(1. - c2**2) * (1. if elbow == 'up' else -1.)
    q2 = np.arctan2(s2, c2)
    q1 = np.arctan2(y, x) - np.arctan2(L2*s2, L1 + L2*c2)
    return np.array([q1, q2])

def ikine_numerical(robot, T_des, q0=None, tol=1e-6, max_iter=200, alpha=0.5):
    """
    Cinematica inversa numerica (Newton-Raphson smorzato).

    Errore di posa 6D:
        e = [p_des - p_cur;  R_cur × vex((R_cur^T R_des - I)/2)]

    Aggiornamento:
        Δq = α * J^† e     (pseudo-inversa Damped Least Squares)

    Parameters
    ----------
    T_des    : (4,4) posa desiderata
    q0       : (n,) configurazione iniziale  (default: zero)
    tol      : tolleranza sull'errore 6D
    alpha    : passo di smorzamento (0 < α ≤ 1)

    Returns
    -------
    dict: 'q', 'success', 'error', 'iters'
    """
    n = robot['n']
    q = np.zeros(n) if q0 is None else np.asarray(q0, float).copy()

    R_des = T_des[:3, :3]
    p_des = T_des[:3,  3]

    for k in range(max_iter):
        T_cur = fk(robot, q)
        R_cur = T_cur[:3, :3]
        p_cur = T_cur[:3,  3]

        # errore posizione
        e_p = p_des - p_cur
        # errore orientazione (linearizzato)
        R_e = R_cur.T @ R_des
        e_o = R_cur @ vex((R_e - R_e.T) / 2.)
        e   = np.concatenate([e_p, e_o])

        err = np.linalg.norm(e)
        if err < tol:
            return {'q': q, 'success': True, 'error': err, 'iters': k}

        J   = jacobian(robot, q)
        lam = 1e-4                  # smorzamento DLS
        J_pinv = J.T @ np.linalg.inv(J @ J.T + lam*np.eye(6))
        q   = q + alpha * J_pinv @ e

        # rispetta i limiti
        lims = np.array([lnk['qlim'] for lnk in robot['links']])
        q    = np.clip(q, lims[:,0], lims[:,1])

    err_fin = np.linalg.norm(e)
    return {'q': q, 'success': False, 'error': err_fin, 'iters': max_iter}

# ──────────────────────────────────────────────────────────────
# 5. Traiettorie nello spazio dei giunti
# ──────────────────────────────────────────────────────────────

def _poly3(q0, qf, T, t):
    """Polinomio di 3° grado: vel. zero agli estremi."""
    s = t / T
    q   = q0 + (qf-q0)*(3*s**2 - 2*s**3)
    dq  = (qf-q0)/T * (6*s - 6*s**2)
    ddq = (qf-q0)/T**2 * (6 - 12*s)
    return q, dq, ddq

def _poly5(q0, qf, T, t):
    """Polinomio di 5° grado: vel. e acc. zero agli estremi."""
    s = t / T
    q   = q0 + (qf-q0)*(10*s**3 - 15*s**4 + 6*s**5)
    dq  = (qf-q0)/T * (30*s**2 - 60*s**3 + 30*s**4)
    ddq = (qf-q0)/T**2 * (60*s - 180*s**2 + 120*s**3)
    return q, dq, ddq

def _lspb(q0, qf, T, t):
    """Profilo trapezoidale LSPB (Linear Segment with Parabolic Blends)."""
    if abs(qf - q0) < 1e-12:
        return np.full_like(t, q0), np.zeros_like(t), np.zeros_like(t)
    v_c = 1.5*(qf - q0)/T          # velocità di crociera
    tb  = np.clip(0.5*T - 0.5*(qf-q0)/v_c, 0, T/2)
    acc = v_c / tb if tb > 1e-12 else 0.

    q, dq, ddq = np.zeros_like(t), np.zeros_like(t), np.zeros_like(t)
    for k, tk in enumerate(t):
        if   tk <= tb:
            q[k]  = q0 + 0.5*acc*tk**2
            dq[k] = acc*tk;  ddq[k] = acc
        elif tk <= T-tb:
            q[k]  = q0 + acc*tb*(tk - tb/2)
            dq[k] = v_c
        else:
            dt_ = T - tk
            q[k]  = qf - 0.5*acc*dt_**2
            dq[k] = acc*dt_;  ddq[k] = -acc
    return q, dq, ddq

def jtraj(q0, qf, T=1.0, dt=0.01, kind='poly5'):
    """
    Traiettoria punto-punto nello spazio dei giunti.

    Parameters
    ----------
    q0, qf : (n,) array  – configurazioni iniziale e finale
    T      : float       – durata [s]
    dt     : float       – passo temporale [s]
    kind   : 'poly3' | 'poly5' | 'lspb'

    Returns
    -------
    Q   : (N, n)  posizioni
    dQ  : (N, n)  velocità
    ddQ : (N, n)  accelerazioni
    t   : (N,)    vettore tempi
    """
    q0  = np.asarray(q0, float)
    qf  = np.asarray(qf, float)
    t   = np.arange(0, T + dt/2, dt)
    N, n = len(t), len(q0)
    Q, dQ, ddQ = np.zeros((N,n)), np.zeros((N,n)), np.zeros((N,n))

    fn = {'poly3': _poly3, 'poly5': _poly5, 'lspb': _lspb}[kind]
    for j in range(n):
        Q[:,j], dQ[:,j], ddQ[:,j] = fn(q0[j], qf[j], T, t)
    return Q, dQ, ddQ, t

def jtraj_multi(waypoints, durations=None, dt=0.01):
    """
    Traiettoria multi-punto via spline cubica con condizioni di clamping
    (velocità nulla all'inizio e alla fine).

    Parameters
    ----------
    waypoints : (M, n) array  – M punti di passaggio
    durations : (M-1,) array  – durata di ogni segmento (default: tutti 1 s)

    Returns
    -------
    Q, dQ, ddQ, t
    """
    wp = np.asarray(waypoints, float)
    M, n = wp.shape
    if durations is None:
        durations = np.ones(M-1)
    t_wp = np.concatenate([[0], np.cumsum(durations)])
    cs   = CubicSpline(t_wp, wp, bc_type='clamped')
    t    = np.arange(0, t_wp[-1] + dt/2, dt)
    return cs(t), cs(t,1), cs(t,2), t

def ctraj(T_start, T_end, T=1.0, dt=0.01):
    """
    Traiettoria cartesiana lineare:
      - Interpolazione lineare della posizione
      - SLERP per l'orientazione (via quaternioni)

    Returns
    -------
    Ts : list di (4,4) matrici omogenee
    t  : (N,) vettore tempi
    """
    t  = np.arange(0, T + dt/2, dt)
    s  = t / T
    p0 = T_start[:3, 3];  pf = T_end[:3, 3]
    q0 = R2quat(T_start[:3,:3]);  qf = R2quat(T_end[:3,:3])
    Ts = []
    for si in s:
        p  = (1-si)*p0 + si*pf
        qi = slerp(q0, qf, si)
        Ti = np.eye(4)
        Ti[:3,:3] = quat2R(qi);  Ti[:3,3] = p
        Ts.append(Ti)
    return Ts, t
